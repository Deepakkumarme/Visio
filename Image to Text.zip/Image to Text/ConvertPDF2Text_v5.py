# import the necessary packages
from PIL import Image
import pytesseract
# import argparse
import cv2
from os import path
from fitz import Document
import os
import fitz

#from ExtractImagesFromPDFFile import *
from FilesLister import listFilesOfType as lf
from SpellingCorrector import Spellar
from shutil import rmtree
import time
from threading import *
import threading

#for test purpose
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys


pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

OPTION_1_SHOW_OUTPUT_FROM_ALL = 0
OPTION_2_PREPROCESS_IMAGE = 1
OPTION_3_RAW_OCR = 2
OPTION_4_RAW_SPELLING = 3
OPTION_5_BEST_ACCURACY = 4


class ConvertPDF2Text_Option2:

    # initialize with the file that needs to be converted
    def __init__(self, file, temppath):


        self.file = file
        self.imageList = []
        self.textData = []
        self.temp_folder = temppath


    def extract(self):
        debug = False
        imageToBeProcessed = True


        if not path.exists(self.temp_folder):
            os.makedirs(self.temp_folder)
            os.chdir(self.temp_folder)
        elif path.exists(self.temp_folder):
            os.chdir(self.temp_folder)


        self.textData.append("OCR Option 1 - Image Preprocessed\n")


        doc = Document(self.file, filetype="pdf")

        for page in doc.pages():

            zoom_x = 3.0  # horizontal zoom
            zomm_y = 3.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zomm_y)
            pixmap = page.getPixmap(matrix=mat, colorspace=fitz.csRGB)
            imgFileName = "page " + str(i) + ".png"
            pixmap.writePNG(imgFileName)
            self.imageList.append(imgFileName)

            image = cv2.imread(imgFileName)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # apply thresholding to preprocess the image
            gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

            # median blurring should be done to remove noise
            #gray = cv2.medianBlur(gray, 3)

            # write the grayscale image to disk as a temporary file so we can apply OCR to it

            filename = "{}.png".format(os.getpid())

            cv2.imwrite(filename, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            custom_config = r'-l hun --psm 6'
            #text = pytesseract.image_to_string(Image.open(filename), custom_config)
            text = pytesseract.image_to_string(Image.open(filename), lang="eng+esp+por")

            self.textData.append(text)
            os.remove(filename)
            i+=1





class ConvertPDF2Text_Option1():

    # initialize with the file that needs to be converted
    def __init__(self, file, temppath):
        #threading.Thread.__init__(self)
        self.file = file
        self.imageList = []
        self.textData = []
        self.temp_folder = temppath


    def extract(self):
#        debug = False
#        imageToBeProcessed = True


        if not path.exists(self.temp_folder):
            os.makedirs(self.temp_folder)
            os.chdir(self.temp_folder)
        elif path.exists(self.temp_folder):
            os.chdir(self.temp_folder)

        #prodessing for option 1
        self.textData.append("Option 1 OCR - Raw Image Processed\n")


        doc = Document(self.file, filetype="pdf")

        for page in doc.pages():

            zoom_x = 3.0  # horizontal zoom
            zomm_y = 3.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zomm_y)
            pixmap = page.getPixmap(matrix=mat, colorspace=fitz.csRGB)
            imgFileName = "page " + str(i) + ".png"
            pixmap.writePNG(imgFileName)
            self.imageList.append(imgFileName)

            image = cv2.imread(imgFileName)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            filename = "{}.png".format(os.getpid())

            cv2.imwrite(filename, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            custom_config = r'eng --psm 6'
            # text = pytesseract.image_to_string(Image.open(filename), custom_config)
            text = pytesseract.image_to_string(Image.open(filename), lang="eng+esp+por")

            self.textData.append(text)

            os.remove(filename)
            i+=1
        self.textData.append("\n")


class ConvertPDF2Text_Option3:

    # initialize with the file that needs to be converted
    def __init__(self, file, temppath):

        self.file = file
        self.imageList = []
        self.textData = []
        self.temp_folder = temppath


    def extract(self):
#        debug = False
#        imageToBeProcessed = True


        if not path.exists(self.temp_folder):
            os.makedirs(self.temp_folder)
            os.chdir(self.temp_folder)
        elif path.exists(self.temp_folder):
            os.chdir(self.temp_folder)


        doc = Document(self.file, filetype="pdf")

        os.chdir(self.temp_folder)
        i = 1
        print("Number of pages in the document----------- : ", doc.pageCount)
        self.textData.append("OCR Option 3 - Raw Image Processed\n")

        for page in doc.pages():

            zoom_x = 3.0  # horizontal zoom
            zomm_y = 3.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zomm_y)
            pixmap = page.getPixmap(matrix=mat, colorspace=fitz.csRGB)
            imgFileName = "page " + str(i) + ".png"
            pixmap.writePNG(imgFileName)
            self.imageList.append(imgFileName)
            #prodessing for option 3

            image = cv2.imread(imgFileName)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            filename = "{}.png".format(os.getpid())

            cv2.imwrite(filename, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            custom_config = r'eng --psm 6'
            # text = pytesseract.image_to_string(Image.open(filename), custom_config)
            text = pytesseract.image_to_string(Image.open(filename), lang="eng+esp+por")

            self.textData.extend(text)
            print("page no processed:", i)
            os.remove(filename)
            i+=1



class ConvertPDF2Text_Option4:

    # initialize with the file that needs to be converted
    def __init__(self, file, temppath):

        self.file = file
        self.imageList = []
        self.textData = []
        self.temp_folder = temppath


    def extract(self):
#        debug = False
#        imageToBeProcessed = True


        if not path.exists(self.temp_folder):
            os.makedirs(self.temp_folder)
            os.chdir(self.temp_folder)
        elif path.exists(self.temp_folder):
            os.chdir(self.temp_folder)



        doc = Document(self.file, filetype="pdf")

        os.chdir(self.temp_folder)
        i = 1
        print("Number of pages in the document----------- : ", doc.pageCount)
        self.textData.append("Option 4 - Raw OCR and Spelling Correction\n")
        for page in doc.pages():

            zoom_x = 3.0  # horizontal zoom
            zomm_y = 3.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zomm_y)
            pixmap = page.getPixmap(matrix=mat, colorspace=fitz.csRGB)
            imgFileName = "page " + str(i) + ".png"
            pixmap.writePNG(imgFileName)
            self.imageList.append(imgFileName)
    #processing for option 4


            corrector = Spellar()

            image = cv2.imread(imgFileName)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            filename = "{}.png".format(os.getpid())

            cv2.imwrite(filename, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            custom_config = r'eng --psm 6'
            # text = pytesseract.image_to_string(Image.open(filename), custom_config)
            text = pytesseract.image_to_string(Image.open(filename), lang="eng+esp+por")
            text = corrector.spellingCorrectorWithPunc(text)

            self.textData.append(text)
            os.remove(filename)
            i+=1


class ConvertPDF2Text_Option5:

    # initialize with the file that needs to be converted
    def __init__(self, file, temppath):

        self.file = file
        self.imageList = []
        self.textData = []
        self.temp_folder = temppath


    def extract(self):
#        debug = False
#        imageToBeProcessed = True


        if not path.exists(self.temp_folder):
            os.makedirs(self.temp_folder)
            os.chdir(self.temp_folder)
        elif path.exists(self.temp_folder):
            os.chdir(self.temp_folder)


        doc = Document(self.file,filetype="pdf")

        os.chdir(self.temp_folder)
        i = 1
        print("Number of pages in the document----------- : ", doc.pageCount)
        self.textData.append("OCR Option 5 - Best Accuracy \n")

        for page in doc.pages():

            zoom_x = 3.0  # horizontal zoom
            zomm_y = 3.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zomm_y)
            pixmap = page.getPixmap(matrix=mat, colorspace = fitz.csRGB)
            imgFileName = "page " + str(i) + ".png"
            pixmap.writePNG(imgFileName)
            self.imageList.append(imgFileName)
        #processing for option 2
            corrector = Spellar()

            image = cv2.imread(imgFileName)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # apply thresholding to preprocess the image
            gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

            # median blurring should be done to remove noise
            gray = cv2.medianBlur(gray, 3)

            # write the grayscale image to disk as a temporary file so we can apply OCR to it

            filename = "{}.png".format(os.getpid())

            cv2.imwrite(filename, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            custom_config = r'eng --psm 6'
            # text = pytesseract.image_to_string(Image.open(filename), custom_config)
            text = pytesseract.image_to_string(Image.open(filename), lang="eng+esp+por")
            text = corrector.spellingCorrectorWithPunc(text)

            self.textData.append(text)
            os.remove(filename)

            i += 1
        self.textData.append("")


def get_pdf_text_images(file, temppath, option):
    converter = None

    if option == OPTION_2_PREPROCESS_IMAGE:
        if file is not None:
            converter = ConvertPDF2Text_Option2(file, temppath)
            converter.extract()

            return converter.textData, converter.imageList
        else:
            return None

    if option == OPTION_1_SHOW_OUTPUT_FROM_ALL:
        if file is not None:
            converter = ConvertPDF2Text_Option1(file, temppath)
            converter.extract()

            return converter.textData, converter.imageList
        else:
            return None

    if option == OPTION_3_RAW_OCR:
        if file is not None:
            converter = ConvertPDF2Text_Option3(file, temppath)
            converter.extract()

            return converter.textData, converter.imageList
        else:
            return None

    if option == OPTION_4_RAW_SPELLING:
        if file is not None:
            converter = ConvertPDF2Text_Option4(file, temppath)
            converter.extract()

            return converter.textData, converter.imageList
        else:
            return None

    if option == OPTION_5_BEST_ACCURACY:
        if file is not None:
            converter = ConvertPDF2Text_Option5(file, temppath)
            converter.extract()

            return converter.textData, converter.imageList
        else:
            return None



if __name__ == '__main__':

    app = QApplication(sys.argv)
    app.setApplicationName("Testing - PDF Manager")


    path_file, _ = QFileDialog.getOpenFileName(None, 'Open file', 'c:\\', "PDF Files (*.pdf)")
    temp_path = os.getcwd()
    print(temp_path)
    print("")
    if path_file != '':
        #create the subWindow


        get_text_list, imageList = get_pdf_text_images(path_file, temp_path,OPTION_5_BEST_ACCURACY)
        get_text_string = ''.join([str(elem) for elem in get_text_list])
        print(get_text_string)

    app.exec_()