import sys
import time
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import QtCore
from PyQt5.QtCore import Qt


class Settings_Config_Dlg(QDialog):
    def __init__(self, parent=None):
        QDialog.__init__(self, parent)
        self.initUI()

    def initUI(self):

        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.option_interactive = QCheckBox("Run Application in Interactive Mode")
        self.layout.addWidget(self.option_interactive)



        self.group_box = QGroupBox("Setting for OCR methodology to be used")
        self.group_box.layout = QVBoxLayout()
        self.layout.addWidget(self.group_box)

        self.option_output_all_options = QRadioButton("Option 1 - Generate output using all options in the text box")
        self.option_image_preprocess = QRadioButton("Option 2 - Generate an output after pre-processing images/pdf")
        self.option_raw_ocr = QRadioButton("Option 3 - Generate raw ocr output from images/pdf")
        self.option_spelling_correct_raw = QRadioButton("Option 4 - Generate raw + spelling corrected output from images/pdf")
        self.option_best_accuracy = QRadioButton("Option 5 - Generate best accuracy = preprocess images + spelling corrected output from images/pdf")

        self.group_box.layout.addWidget(self.option_output_all_options)
        self.group_box.layout.addWidget(self.option_image_preprocess)
        self.group_box.layout.addWidget(self.option_raw_ocr)
        self.group_box.layout.addWidget(self.option_spelling_correct_raw)
        self.group_box.layout.addWidget(self.option_best_accuracy)

        self.group_box.setLayout(self.group_box.layout)



        self.save_button = QPushButton("Save Settings", self)
        self.layout.addWidget(self.save_button)


        self.setGeometry(300, 300, 500, 400)
