import filetype
import glob

def iffiletypepdf(filepath):
    kind = filetype.guess(filepath)
    if kind is None:
        print('Cannot guess file type!')
        return

#    print('File extension: %s' % kind.extension)
#    print('File MIME type: %s' % kind.mime)
    extension = kind.extension
    mimetype = kind.mime
    if mimetype == "application/pdf" and extension is "pdf":
        return "pdf"
    if mimetype == "application/pdf" and extension is None:
        return "maybepdf"
    if mimetype == "application/pdf" and extension is not 'pdf':
        return "maybepdf"
    if extension is 'pdf' and mimetype != "application/pdf":
        return 'maynotbepdf'
    return 'other'


def listFilesOfType(basepath, filetype):
    if filetype == "pdf":
        pattern = basepath + '**\\' + "*.pdf"
        files = glob.glob(pattern, recursive=True)
        return files
    if filetype == "png":
        pattern = basepath + '**\\' + "*.png"
        files = glob.glob(pattern, recursive=True)
        return files



