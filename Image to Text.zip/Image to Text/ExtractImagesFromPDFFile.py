from fitz import Document
import os
import fitz


def extractimagesPDF(file, outpath):
    doc = Document(file,filetype="pdf")
    os.chdir(outpath)
#    os.mkdir(os.path.basename(file))
#    os.chdir(os.path.join(outpath, os.path.basename(file)))
    for i in range(len(doc)):
        for img in doc.getPageImageList(i):
            xref = img[0]
            pix = fitz.Pixmap(doc, xref)

            imgfilename = "page " + str(i) + str(xref) +".png"
            if pix.n - pix.alpha < 4:       # this is GRAY, or RGB, or CMYK
                pix.writePNG(imgfilename)
            else:               # CMYK: convert to RGB first
                pix1 = fitz.Pixmap(fitz.csRGB, pix)
                pix1.writePNG(imgfilename)
                pix1 = None
            pix = None


def extractPixmaps(file, outpath):
    doc = Document(file,filetype="pdf")
    #doc.getPagePixmap()
    os.chdir(outpath)
    i = 1
#    os.mkdir(os.path.basename(file))
#    os.chdir(os.path.join(outpath, os.path.basename(file)))
    print("Number of pages in the document----------- : ", doc.pageCount)
    for page in doc.pages():

        zoom_x = 3.0  # horizontal zoom
        zomm_y = 3.0  # vertical zoom
        mat = fitz.Matrix(zoom_x, zomm_y)
        pixmap = page.getPixmap(matrix=mat, colorspace = fitz.csRGB)
        imgFileName = "page " + str(i) + ".png"
        pixmap.writePNG(imgFileName)
        print("pixmap extracted for page : ", i)
        i += 1
    return

#out = r"C:\Users\amittal1\PycharmProjects\PDFConversionPoC\out"
#extractPixmaps(r"C:\Users\amittal1\PycharmProjects\PDFConversionPoC\venv\2 with handwriting - no need to pull handwriting.pdf", out)
