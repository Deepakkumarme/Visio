import sys
import time
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import QtCore
from PyQt5.QtCore import Qt


class Find_Replace_Dialog(QDialog):
    def __init__(self, parent=None):
        QDialog.__init__(self, parent)

        self.cs = False
        self.wwo = False
        self.initUI()

    def initUI(self):

        self.lb1 = QLabel("Search for: ", self)
        self.lb1.setStyleSheet("font-size: 15px; ")
        self.lb1.move(10, 10)

        self.text_search = QTextEdit(self)
        self.text_search.move(10, 40)
        self.text_search.resize(250, 25)

        self.src_button = QPushButton("Find", self)
        self.src_button.move(270, 40)

        self.lb2 = QLabel("Replace all by: ", self)
        self.lb2.setStyleSheet("font-size: 15px; ")
        self.lb2.move(10, 80)

        self.replace_with = QTextEdit(self)
        self.replace_with.move(10, 110)
        self.replace_with.resize(250, 25)

        self.replace_button = QPushButton("Replace", self)
        self.replace_button.move(270, 110)

        self.opt_case_sensitivity = QCheckBox("Case sensitive", self)
        self.opt_case_sensitivity.move(10, 160)
        self.opt_case_sensitivity.stateChanged.connect(self.CS)

        self.opt_whole_words = QCheckBox("Whole words only", self)
        self.opt_whole_words.move(10, 190)
        self.opt_whole_words.stateChanged.connect(self.WWO)

        self.close_button = QPushButton("Close", self)
        self.close_button.move(270, 220)
        self.close_button.clicked.connect(self.Close)

        self.setGeometry(300, 300, 360, 250)

    def CS(self, state):
        if state == QtCore.Qt.Checked:
            self.cs = True
        else:
            self.cs = False

    def WWO(self, state):
        if state == QtCore.Qt.Checked:
            self.wwo = True
        else:
            self.wwo = False

    def Close(self):
        self.hide()