import enchant

import locale

broker = enchant.Broker()
print(broker.describe())
print(broker.list_languages())
#print(enchant.list_dicts)

print(enchant.dict_exists("en_US"))

try:
    tag = locale.getlocale()[0]
    print("locale is set as : ",tag)
    if tag is None:
        tag = locale.getdefaultlocale()[0]
        if tag is None:
            raise Error("No default language available")

except Exception:
    pass