from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from os import path
import uuid
import os
from Spell_Checked_Edit_Syntax_Highlight import SpellTextEdit
from Find_Replace_Dialog import Find_Replace_Dialog
import shutil

def hexuuid():
    return uuid.uuid4().hex

class SubWindow(QMdiSubWindow):
    def __init__(self,*args, **kwargs):
        super(SubWindow, self).__init__(*args, **kwargs)
        self.TEMP_PATH = path.expandvars(r'%LOCALAPPDATA%\MetIAPDF\temp')

        self.setAttribute(Qt.WA_DeleteOnClose)

        self.centralwidget = QWidget()

        self.setWidget(self.centralwidget)
        self.layout = QHBoxLayout(self.centralwidget)
        self.layout.text_edit = SpellTextEdit()
        self.layout.text_edit.setMaximumWidth(500)
        # sub.layout.addStretch(1)
        self.layout.addWidget(self.layout.text_edit)

        self.layout.image_layout = QVBoxLayout()
        self.layout.addLayout(self.layout.image_layout)

        # image control creation as a QLabel
        self.layout.image_layout.imageControl = QLabel()
        self.layout.image_layout.imageControl.setScaledContents(True)

        # image in the scrolling area
        self.layout.image_layout.scrollArea = QScrollArea()
        self.layout.image_layout.scrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.layout.image_layout.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.layout.image_layout.scrollArea.setWidgetResizable(True)
        self.layout.image_layout.scrollArea.setBackgroundRole(QPalette.Dark)
        self.layout.image_layout.addWidget(self.layout.image_layout.scrollArea)
        self.layout.image_layout.scrollArea.setWidget(self.layout.image_layout.imageControl)

        self.layout.image_layout.imageControl.show()
        self.layout.image_layout.scrollArea.show()

        self.layout.image_layout.imageList = []
        self.hexid = hexuuid()
        self.temp_path = os.path.join(self.TEMP_PATH, self.hexid)

        self.layout.image_layout.button_layout = QHBoxLayout()
        self.layout.image_layout.addLayout(self.layout.image_layout.button_layout)
        self.layout.image_layout.button_layout.button_group = QButtonGroup()

        self.layout.image_layout.button_layout.first_button = QPushButton("First")
        self.layout.image_layout.button_layout.button_group.addButton(
            self.layout.image_layout.button_layout.first_button)
        self.layout.image_layout.button_layout.addWidget(self.layout.image_layout.button_layout.first_button)
        self.layout.image_layout.button_layout.first_button.setEnabled(False)

        self.layout.image_layout.button_layout.previous_button = QPushButton("Previous")
        self.layout.image_layout.button_layout.button_group.addButton(
            self.layout.image_layout.button_layout.previous_button)
        self.layout.image_layout.button_layout.addWidget(self.layout.image_layout.button_layout.previous_button)

        self.layout.image_layout.button_layout.next_button = QPushButton("Next")
        self.layout.image_layout.button_layout.button_group.addButton(
            self.layout.image_layout.button_layout.next_button)
        self.layout.image_layout.button_layout.addWidget(self.layout.image_layout.button_layout.next_button)

        self.layout.image_layout.button_layout.last_button = QPushButton("Last")
        self.layout.image_layout.button_layout.button_group.addButton(
            self.layout.image_layout.button_layout.last_button)
        self.layout.image_layout.button_layout.addWidget(self.layout.image_layout.button_layout.last_button)



    def closeEvent(self, event):

        self.layout.text_edit.destroy()
        self.layout.image_layout.imageControl.destroy()

        event.accept()




    def setButtons(self, first, previous, next, last):
        self.layout.image_layout.button_layout.first_button.setEnabled(first)
        self.layout.image_layout.button_layout.previous_button.setEnabled(previous)
        self.layout.image_layout.button_layout.next_button.setEnabled(next)
        self.layout.image_layout.button_layout.last_button.setEnabled(last)



