#import textblob


import textblob
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from os import path
import shutil
import sys
import nltk


from Spell_Checked_Edit_Syntax_Highlight import SpellTextEdit
from Find_Replace_Dialog import Find_Replace_Dialog
from Settings_Config_Dlg import Settings_Config_Dlg
from ConvertPDF2Text_v5 import *
from PDFSubWindow import SubWindow

from distutils import util

def splitext(p):
    return os.path.splitext(p)[1].lower()

class MainWindow(QMainWindow):
    count = 0
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.OPTION_SHOW_OUTPUT_FROM_ALL = 0
        self.OPTION_PREPROCESS_IMAGE = 1
        self.OPTION_RAW_OCR = 2
        self.OPTION_RAW_SPELLING = 3
        self.OPTION_BEST_ACCURACY = 4
        self.TEMP_PATH = path.expandvars(r'%LOCALAPPDATA%\MetIAPDF\temp')

        if not path.exists(self.TEMP_PATH):
            os.makedirs(self.TEMP_PATH)
        else:
            shutil.rmtree(self.TEMP_PATH,ignore_errors=True)
            time.sleep(2)

        #setup the MDI architecture and MDI Windows - toolbars, statusbar, etc.
        self.mdiArea = QMdiArea()
        self.setCentralWidget(self.mdiArea)
        self.mdiArea.parent = self

        #status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)

        #toolbar - file
        file_toolbar = QToolBar("File")
        file_toolbar.setIconSize(QSize(14, 14))
        self.addToolBar(file_toolbar)
        self.menu_bar = self.menuBar()

        # menubar - File, Edit, Window
        self.file_menu = self.menu_bar.addMenu("&File")
        self.edit_menu = self.menu_bar.addMenu("&Edit")
        self.window_menu = self.menu_bar.addMenu("&Window")

        #creating different menu and associated action-handlers

        #open PDF menu and action
        open_file_action = QAction(QIcon(os.path.join('images', 'blue-folder-open-document.png')), "Open PDF", self)
        open_file_action.setStatusTip("Open PDF file")
        self.file_menu.addAction(open_file_action)
        file_toolbar.addAction(open_file_action)

        #save menu and action
        self.save_file_action = QAction(QIcon(os.path.join('images', 'disk.png')), "Save", self)
        self.save_file_action.setStatusTip("Save the current file as text")
#        save_file_action.triggered.connect(self.file_save)
        self.file_menu.addAction(self.save_file_action)
        file_toolbar.addAction(self.save_file_action)

        #close active file menu and action
        self.close_active_action = QAction(QIcon(os.path.join('images', 'blue-document-cross-icon.png')), "Close", self)
        self.close_active_action.setStatusTip("Close Active Window")
        self.file_menu.addAction(self.close_active_action)
        file_toolbar.addAction(self.close_active_action)

        #close all active windows and action
        self.close_all_action = QAction(QIcon(os.path.join('images', 'icons8-close-all-tabs-16.png')), "Close All", self)
        self.close_all_action.setStatusTip("Close All Windows")
        self.file_menu.addAction(self.close_all_action)
        file_toolbar.addAction(self.close_all_action)

        self.settings_and_config_action = QAction(QIcon(os.path.join('images', 'configuration-icon.png')), "Settings", self)
        self.close_all_action.setStatusTip("Setup Application Configuration and Settings")
        self.file_menu.addAction(self.settings_and_config_action)
        file_toolbar.addAction(self.settings_and_config_action)

        #assigning the action handlers (slots)
        self.file_menu.triggered[QAction].connect(self.WindowTrig)

        #edit menu ---> Find and Replace
        self.find_replace_action = QAction(QIcon(os.path.join('images', 'new_seo-31-512.png')), "Find", self)
        self.find_replace_action.setStatusTip("Find and replace")
        self.edit_menu.addAction(self.find_replace_action)
        self.edit_menu.setEnabled(False)

        #edit Menu for - Find and Replace currently - change not required for Undo and Redo
        self.edit_menu.triggered[QAction].connect(self.WindowTrig)


        ## Find Dilaog is created and initialized however not shown the same is shown to the user when the related slot is activated
        self.find_dlg = Find_Replace_Dialog()
        self.find_dlg.replace_button.clicked.connect(self.replace_text)
        self.find_dlg.src_button.clicked.connect(self.find_text)

        #initialize settings and setup the settings dialog to be shown
        self.read_settings_and_intialize()

        # Windows management #
        tile_window_action = QAction(QIcon(os.path.join('images', 'icons8-view-all-16.png')), "Tile", self)
        tile_window_action.setStatusTip("Tile All Windows")
        self.window_menu.addAction(tile_window_action)

        cascade_window_action = QAction(QIcon(os.path.join('images', 'application-cascade-icon.png')), "Cascade", self)
        cascade_window_action.setStatusTip("Cascade All Windows")
        self.window_menu.addAction(cascade_window_action)
        self.window_menu.triggered[QAction].connect(self.WindowTrig)


        # Initialize
        self.update_title()
        self.disable_menus()
        self.showMaximized()
        self.mdiArea.subWindowActivated.connect(self.updateMenus)

    def updateMenus(self):
        if len(self.mdiArea.subWindowList()) == 0:
            self.disable_menus()
        elif len(self.mdiArea.subWindowList()) > 0:
            self.enable_menus()

    def read_settings_and_intialize(self):
        # Settings and Config Dialog
        QCoreApplication.setOrganizationName("MetLife IA")
        QCoreApplication.setApplicationName("OCR and PDF Management Tool")
        self.settings = QSettings()
        self.config_dlg = Settings_Config_Dlg()
        self.config_dlg.save_button.clicked.connect(self.save_config_from_dlg)

        # Read and setup settings to be default if the setting is not picked from the registry
        inter_mode = self.settings.value("InteractiveMode")
        if inter_mode is None:
            self.setting_interactive_mode = "True"
            self.config_dlg.option_interactive.setChecked(True)
        else:
            self.setting_interactive_mode = self.settings.value("InteractiveMode")
            mode = True
            if self.settings.value("InteractiveMode") == "True":
                mode = True
            elif self.settings.value("InteractiveMode") == "False":
                mode = False
            self.config_dlg.option_interactive.setChecked(mode)

        op_mode = self.settings.value("OperationMode")
        if op_mode is None:
            self.setting_operation_mode = self.OPTION_SHOW_OUTPUT_FROM_ALL
            self.config_dlg.option_output_all_options.setChecked(True)
        else:
            self.setting_operation_mode = self.settings.value("OperationMode")

            if self.setting_operation_mode == self.OPTION_SHOW_OUTPUT_FROM_ALL:
                self.config_dlg.option_output_all_options.setChecked(True)

            elif self.setting_operation_mode == self.OPTION_PREPROCESS_IMAGE:
                self.config_dlg.option_image_preprocess.setChecked(True)

            elif self.setting_operation_mode == self.OPTION_RAW_OCR:
                self.config_dlg.option_raw_ocr.setChecked(True)

            elif self.setting_operation_mode == self.OPTION_RAW_SPELLING:
                self.config_dlg.option_spelling_correct_raw.setChecked(True)

            elif self.setting_operation_mode == self.OPTION_BEST_ACCURACY:
                self.config_dlg.option_best_accuracy.setChecked(True)

    def save_config_from_dlg(self):
        if self.config_dlg.option_interactive.isChecked():
            self.setting_interactive_mode = "True"
        else:
            self.setting_interactive_mode = "False"

        if self.config_dlg.option_output_all_options.isChecked():
            self.setting_operation_mode = self.OPTION_SHOW_OUTPUT_FROM_ALL

        elif self.config_dlg.option_image_preprocess.isChecked():
            self.setting_operation_mode = self.OPTION_PREPROCESS_IMAGE

        elif self.config_dlg.option_raw_ocr.isChecked():
            self.setting_operation_mode = self.OPTION_RAW_OCR

        elif self.config_dlg.option_spelling_correct_raw.isChecked():
            self.setting_operation_mode = self.OPTION_RAW_SPELLING

        elif self.config_dlg.option_best_accuracy.isChecked():
            self.setting_operation_mode = self.OPTION_BEST_ACCURACY

        self.config_dlg.hide()

    def find_text(self):
        f = self.find_dlg.text_search.toPlainText()
        print(f)

        flag = QTextDocument.FindFlag(0)

        if self.find_dlg.cs == True and self.find_dlg.wwo == False:
            flag = QTextDocument.FindBackward and QTextDocument.FindCaseSensitively

        elif self.find_dlg.cs == True and self.find_dlg.wwo == False:
            flag = QTextDocument.FindBackward

        elif self.find_dlg.cs == True and self.find_dlg.wwo == True:
            flag = QTextDocument.FindBackward and QTextDocument.FindWholeWords

        elif self.find_dlg.cs == True and self.find_dlg.wwo == True:
            flag = QTextDocument.FindBackward and QTextDocument.FindCaseSensitively and QTextDocument.FindWholeWords


        active_sub_window = self.mdiArea.activeSubWindow()

        active_sub_window.layout.text_edit.find(f, flag)


    def replace_text(self):
        f = self.find_dlg.text_search.toPlainText()
        print(f)

        r = self.find_dlg.replace_with.toPlainText()
        print(r)

        active_sub_window = self.mdiArea.activeSubWindow()
        text = active_sub_window.layout.text_edit.toPlainText()

        newText = text.replace(f, r)

        active_sub_window.layout.text_edit.clear()
        active_sub_window.layout.text_edit.setPlainText(newText)

    def WindowTrig(self, p):
        """this function acts a primary slot (action-handler) for this application"""

        if p.text() == "Open PDF":
            self.open_pdf_file()

        if p.text() == "Close":
            self.close_active_file()

        if p.text() == "Close All":
            self.close_all_windows()

        if p.text() == "Settings":
            self.setup_app_config()

        if p.text == "Exit":
            self.exit_app()

        if p.text() == "Find":
            self.find_dlg.show()

        if p.text() == "Cascade":
            self.mdiArea.cascadeSubWindows()

        if p.text() == "Save":
            self.file_save_active_window()

        if p.text() == "Tile":
            self.mdiArea.tileSubWindows()

    def open_pdf_file(self):

        """ This function creates the sub window and populates it with the extracted test based on the pdf file chosen
        by the user. In case, user does not select the file from the file open dialog, it shows the message box to the
        user and function returns"""

        sub = None
        path_file, _ = QFileDialog.getOpenFileName(self, 'Open file', 'c:\\', "PDF Files (*.pdf)")

        if path_file != '':
            #create the subWindow
            sub = SubWindow()
            sub.path = path_file
            get_text_list, sub.layout.imageList = get_pdf_text_images(sub.path, sub.temp_path, self.setting_operation_mode)
            get_text_string = ''.join([str(elem) for elem in get_text_list])
            print(get_text_string)
            # text_font = QFont('Arial Unicode MS')
            # sub.layout.text_edit.setFont(text_font)
            sub.layout.text_edit.setPlainText(get_text_string)
            sub.layout.image_layout.imageControl.setPixmap(QPixmap(sub.layout.imageList[0]).scaled(QSize(800, 640)))
            sub.currentImageNo = 0

            if len(sub.layout.imageList) == 1:
                sub.setButtons(0,0,0,0)
            elif len(sub.layout.imageList) > 1:
                sub.setButtons(0,0,1,1)

            sub.layout.image_layout.button_layout.button_group.buttonClicked['QAbstractButton *'].connect(self.image_button_clicked)


            # sub.layout.addWidget()
            # sub.layout.imageControl.resize()
            self.edit_menu.setEnabled(True)
            # sub.layout.imageControl.scroll()
            # print(get_text_string)    #use for debug
            sub.setWindowTitle(sub.path)
            self.mdiArea.addSubWindow(sub)
            sub.layout.text_edit.show()
            sub.layout.image_layout.scrollArea.show()
            sub.layout.image_layout.imageControl.show()


            # sub.addLayout(sub.layout)

            sub.showMaximized()

        elif path_file == '':
            self.dialog_critical("No file is selected to be opened")
            return

        return

    def image_button_clicked(self, button):
        currentImgNo = self.mdiArea.activeSubWindow().currentImageNo
        sub = self.mdiArea.activeSubWindow()
        if button.text() == 'First':
            sub.layout.image_layout.imageControl.setPixmap(QPixmap(sub.layout.imageList[0]).scaled(QSize(800, 640)))
            self.mdiArea.activeSubWindow().currentImageNo = 0

        if button.text() == 'Previous':
            sub.layout.image_layout.imageControl.setPixmap(
                QPixmap(sub.layout.imageList[self.mdiArea.activeSubWindow().currentImageNo - 1]).scaled(
                    QSize(800, 640)))
            self.mdiArea.activeSubWindow().currentImageNo -= 1
            if self.mdiArea.activeSubWindow().currentImageNo == 0:
                sub.setButtons(0, 0, 1, 1)
            elif self.mdiArea.activeSubWindow().currentImageNo < len(sub.layout.imageList) - 1:
                sub.setButtons(1, 1, 1, 1)

        if button.text() == 'Next':
            sub.layout.image_layout.imageControl.setPixmap(
                QPixmap(sub.layout.imageList[self.mdiArea.activeSubWindow().currentImageNo + 1]).scaled(QSize(800, 640)))
            self.mdiArea.activeSubWindow().currentImageNo += 1
            if self.mdiArea.activeSubWindow().currentImageNo == len(sub.layout.imageList)-1:
                sub.setButtons(1, 1, 0, 0)
            elif self.mdiArea.activeSubWindow().currentImageNo  < len(sub.layout.imageList)-1 :
                sub.setButtons(1, 1, 1, 1)

        if button.text() == 'Last':
            sub.layout.image_layout.imageControl.setPixmap(QPixmap(sub.layout.imageList[len(sub.layout.imageList)-1]).scaled(QSize(800, 640)))
            self.mdiArea.activeSubWindow().currentImageNo = len(sub.layout.imageList)-1
            if len(sub.layout.imageList) == 1:
                sub.setButtons(0,0,0,0)
            elif len(sub.layout.imageList) > 1:
                sub.setButtons(1,1,0,0)


    def dialog_critical(self, s):
        dlg = QMessageBox(self)
        dlg.setText(s)
        dlg.setIcon(QMessageBox.Critical)
        dlg.show()

    def setup_app_config(self):

        self.config_dlg.show()
        self.config_dlg.exec_()

    def closeEvent(self, event):
        """ PyQT Slot to handle the main window close signal. Exit the application. Checks that the files are saved and the text edits
        are not dirty, if the text edits are dirty, confirms with the user, and exits the application"""
        if len(self.mdiArea.subWindowList()) == 0:

            self.save_settings()
            self.settings.sync()
            event.accept()
            self.remove_temp_files()
            return

        else:
            ui_sure_save_yes_no = QMessageBox.question(self, 'Confirmation - Before Closing the Application',
                                                        "Click <Cancel> if not sure, <Yes> to save files before exit, and <No> to exit without saving",
                                                        QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                                                        QMessageBox.Cancel)
            print(int(ui_sure_save_yes_no))
            if ui_sure_save_yes_no == QMessageBox.Yes:
                self.save_all_files()
                time.sleep(2)
                self.mdiArea.closeAllSubWindows()
                for w in self.mdiArea.subWindowList():
                    w.destroy()

                self.save_settings()
                self.settings.sync()
                event.accept()
                self.remove_temp_files()

            if ui_sure_save_yes_no == QMessageBox.No:
                self.status.showMessage("Files not saved as per user's input and closed", 5000)
                self.mdiArea.closeAllSubWindows()
                for w in self.mdiArea.subWindowList():
                    w.destroy()

                self.save_settings()
                self.settings.sync()
                event.accept()
                self.remove_temp_files()

            if ui_sure_save_yes_no == QMessageBox.Cancel:
                self.status.showMessage("No action taken as user cancelled the operation", 5000)
                event.ignore()
            return

    def close_active_file(self):
        """ PyQT Slot to handle the Close signal. Closes the active sub-window of the application. Checks that the file is saved and the text edit
                is not dirty, if the text edit is dirty, confirms with the user, and closes the active sub-window"""

        ui_file_save_yes_no = QMessageBox.question(self, 'File Save - Before Closing', "Do you want to save the current file before closing?",
                                           QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Cancel)
        print(int(ui_file_save_yes_no))
        if ui_file_save_yes_no == QMessageBox.Yes:
            self.file_save_active_window()
            subWindow = self.mdiArea.activeSubWindow()
            subWindow.close()
            subWindow.destroy()

        if ui_file_save_yes_no == QMessageBox.No:
            self.status.showMessage("File not saved as per user's input and closed", 5000)
            subWindow = self.mdiArea.activeSubWindow()
            subWindow.close()
            subWindow.destroy()

        if ui_file_save_yes_no == QMessageBox.Cancel:
            self.status.showMessage("No action taken as user cancelled the operation", 5000)

        if len(self.mdiArea.subWindowList()) == 0:
            self.disable_menus()
        return

    def disable_menus(self):
        self.edit_menu.setEnabled(False)
        self.close_all_action.setEnabled(False)
        self.close_active_action.setEnabled(False)
        self.save_file_action.setEnabled(False)
        self.window_menu.setEnabled(False)

    def enable_menus(self):
        self.edit_menu.setEnabled(True)
        self.close_all_action.setEnabled(True)
        self.close_active_action.setEnabled(True)
        self.save_file_action.setEnabled(True)
        self.window_menu.setEnabled(True)

    def close_all_windows(self):
        """ PyQT Slot to handle the Close All signal. Closes all of the open sub-windows of the application. Checks that the files are saved and the text edits
                        are not dirty, if the text edits are dirty, confirms with the user, and closes all of the sub-windows"""

        ui_files_save_yes_no = QMessageBox.question(self, 'Files Save - Before Closing',
                                                   "Do you want to save the all files before closing?",
                                                   QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                                                   QMessageBox.Cancel)
        print(int(ui_files_save_yes_no))
        if ui_files_save_yes_no == QMessageBox.Yes:
            self.save_all_files()
            time.sleep(2)
            self.mdiArea.closeAllSubWindows()
            self.disable_menus()


        if ui_files_save_yes_no == QMessageBox.No:
            self.status.showMessage("Files not saved as per user's input and closed", 5000)
            subWindow = self.mdiArea.closeAllSubWindows()
            self.disable_menus()

        if ui_files_save_yes_no == QMessageBox.Cancel:
            self.status.showMessage("No action taken as user cancelled the operation", 5000)


        return

    def save_all_files(self):
        for window in self.mdiArea.subWindowList():
            self.save_file_window(window)

    def remove_temp_files(self):
        shutil.rmtree(self.TEMP_PATH, ignore_errors=True)

    def save_settings(self):
        if self.setting_interactive_mode == "True":
            mode = "True"
        elif self.setting_interactive_mode == "False":
            mode = "False"
        self.settings.setValue("InteractiveMode",  mode)
        self.settings.setValue("OperationMode", self.setting_operation_mode)

    def file_save_active_window(self):
        #if self.mdiArea.activeSubWindow().path is None:
            # If we do not have a path, we need to use Save As.
        #    return self.file_saveas()
        active_sub_window = self.mdiArea.activeSubWindow()
        self.save_file_window(active_sub_window)

    def save_file_window(self, window):
        text = window.layout.text_edit.toPlainText()

        file_path = os.path.splitext(window.path)
        print(file_path[0])
        try:
            with open(os.path.normpath(file_path[0] +'.txt'), 'w', encoding='utf-8') as f:
                f.write(text)
                self.status.showMessage("File saved at: " + os.path.normpath(file_path[0] +'.txt'), 10000)
        except Exception as e:
            self.dialog_critical(str(e))

    def update_title(self):
        self.setWindowTitle("MetLife IA Image to Text Tool")



if __name__ == '__main__':

    app = QApplication(sys.argv)
    app.setApplicationName("MetLife IA PDF/Image to Text Tool")

    window = MainWindow()
    app.exec_()