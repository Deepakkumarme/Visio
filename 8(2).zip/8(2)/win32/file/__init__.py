from win32._file import *
from win32._file import _get_osfhandle