from .main import docx2python

