import sys,os
sys.path.append(os.path.join(os.getcwd(), 'lib'))