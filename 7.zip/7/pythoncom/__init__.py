from win32._com import *
from win32._com import _GetGatewayCount, _GetInterfaceCount