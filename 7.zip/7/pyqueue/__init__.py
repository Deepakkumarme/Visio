"""
Pyqueue main module
"""

__version__ = '2.0.0'

from .commands import Commands
from .job import Job
