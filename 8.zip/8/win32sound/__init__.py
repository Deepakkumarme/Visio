from win32.directsound import *
