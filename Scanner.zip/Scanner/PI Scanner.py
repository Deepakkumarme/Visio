#!/usr/bin/env python
# coding: utf-8

# In[9]:


# Import Packages



from tkinter import *
import tkinter
from tkinter import filedialog
from tkinter import messagebox

import webbrowser

import sys

import fitz

try:
    from PIL import Image, ImageTk
    from PIL import ImageGrab
except ImportError:
    import Image
import pytesseract

from pathlib import Path
import time
import os
import pandas as pd

import threading

from docx2python import docx2python
import docx
from docx import Document as Doc
# import PyPDF2
import numpy as np
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

import re
import os
import win32com.client as win32
from win32com.client import constants
from glob import glob
import xlrd
from xlrd import XLRDError
from zipfile36 import ZipFile
# import slate

from IPython.core.debugger import set_trace

import shutil
import datetime

import subprocess

# code change for xlsb
from pyxlsb import open_workbook as open_xlsb

from xlwt import Workbook
import xlsxwriter
import openpyxl

from io import BytesIO
import io

from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage

from csv import reader

# define global variables here

global start_time
global err_list
err_list = [[], []]

mainwindow = tkinter.Tk()

global OCR_flag
OCR_flag = tkinter.IntVar()

#global excel
# excel = win32.gencache.EnsureDispatch('Excel.Application')
#excel = win32.dynamic.Dispatch('Excel.Application')

global OPTIONS
OPTIONS = [
        "Jan",
        "Feb",
        "Mar"
    ]  # etc


# Directory to be searched - this needs to be selected by the user
def selectfolder():
    global mainwindow
    global import_dir
    #global T
    global T2

    root = tkinter.Tk()
    root.withdraw()

    currdir = os.getcwd()

    import_dir = filedialog.askdirectory(parent=root, title='Please select a folder.')





    #if len(import_dir) <= 0:
    #    terminate_thread()

    if len(import_dir) > 0:
        #mainwindow.after(0, lambda: T.config(text=import_dir))

        mainwindow.after(0, lambda: T2.configure(state="normal"))
        mainwindow.after(0, lambda: T2.delete("1.0", "end"))
        mainwindow.after(0, lambda: T2.insert("1.0", import_dir))
        mainwindow.after(0, lambda: T2.configure(state="disabled"))

        print("show directory ", import_dir)


# List of Patterns selected by user - Patterns.csv must contain a list of all patterns and must be included in the tool package.
# The user should delete the patterns they do not wish to search
def definepattern():
    # KeywordTemplate_data = pd.read_excel('C:\Python\PI Scan\Templates\Keywords Short Name.xlsx', sheet_name="Keyword")
    # KeywordTemplate_data = KeywordTemplate_data[KeywordTemplate_data.InScope == "Yes"]

    Pattern_data = pd.read_excel(r"PI Scan\Templates\Keywords Short Name.xlsx", sheet_name="Pattern")
    Pattern_data = Pattern_data[Pattern_data.InScope == "Yes"]

    # print(Pattern_data.values.tolist())

    global patterns
    global patterns_regex
    global patterns_score
    # patterns = pd.read_csv(r"C:\Python\PI Scan\Patterns.csv").values.tolist()
    # patterns = [i[0] for i in patterns]

    patterns = [i[0] for i in Pattern_data.values.tolist()]
    patterns_regex = [i[1] for i in Pattern_data.values.tolist()]
    patterns_score = [i[2] for i in Pattern_data.values.tolist()]

    global ssn_pattern

    # Patterns - Define regular expressions for PII

    # SSN
    # ssn_pattern = '(?!000|.+0{4})(?:\d{9,10}|\d{3,4}-\d{2}-\d{4})'


def definekeywords():
    # PHI and other keywords
    global Keywords
    global Keywords_category
    global Keywords_score

    global KeywordTemplate_data

    KeywordTemplate_data = pd.read_excel(r'PI Scan\Templates\Keywords Short Name.xlsx', sheet_name="Keyword")

    KeywordTemplate_data = KeywordTemplate_data[KeywordTemplate_data.InScope == "Yes"]

    # Keywords = KeywordTemplate_data["Keywords to be searched in Each File"].values.tolist()
    Keywords = [i[0] for i in KeywordTemplate_data.values.tolist()]
    Keywords_category = [i[3] for i in KeywordTemplate_data.values.tolist()]
    Keywords_score = [i[1] for i in KeywordTemplate_data.values.tolist()]

    Keywords = [item.lower() for item in Keywords]


# Initialize Datasets to store extracted PII
def initializeDatasets():
    global pattern_final
    global Keyword_final
    global final_list
    global button1, button2, button3, button4, button5, button6

    pattern_final = pd.DataFrame(
        columns=["PII_Extracted", "File", "Type", "Keyword1", "Keyword2", "Pattern_or_Keyword", "Score"])
    Keyword_final = pd.DataFrame(
        columns=["PII_Extracted", "File", "Type", "Keyword", "Keyword2", "Pattern_or_Keyword", "Score"])
    # final_list = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Keyword2","Pattern_or_Keyword"])
    final_list = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"])

    pt = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"])

    try:
        pt.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="w", index=False, encoding='utf-8-sig')
        error_report = pd.DataFrame(columns=["File", "Error", "Type"])
        error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="w", index=False, encoding='utf-8-sig')
    except Exception as err:
        file = pd.DataFrame(["PI Scan\Output Data\Final_Output-temp.csv"], columns=['File'])
        error = pd.DataFrame([err], columns=['Error'])
        errortype = pd.DataFrame(['Permission Denied - file is open by another process'], columns=['Type'])
        error_report = pd.concat([file, error, errortype], axis=1)

        error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="w", index=False, encoding='utf-8-sig')
        return -1


    return 0
    #error_report = pd.DataFrame(columns=["File", "Error", "Type"])
    #error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="w", index=False, encoding='utf-8-sig')


def walk_through(dirname):
    l = []
    for root, dirs, files in os.walk(dirname):
        for name in files:
            if name.endswith((".pptx", ".pdf", ".docx", ".docm", ".doc", ".xlsx", ".xls", ".xlsm",".xlsb",".zip", ".txt",".csv")):
                l.append((os.path.join(root, name)))
    return l


# Walk through directories - this makes a list of ppt, pdf, Word and Excel files in the directory
def execute_walk_through():
    start_time = time.time()

    global inputfiles
    inputfiles = walk_through(import_dir)
    print("--- %s seconds --- walk through folders" % (time.time() - start_time))


# Unzip zipped files

def file_unzip(file, out_path):
    with ZipFile(file) as zipObj:
        zipObj.extractall(out_path)


# Create separate lists of files for each file type
def list_files():
    global d
    global pp
    global pdf

    global xl
    global zp
    global d2

    global tx
    global dm
    global xlsm
    global xlsb  # code change for xlsb
    global csv  # codechange for csv

    d = []
    pp = []
    pdf = []
    d2 = []
    xl = []
    zp = []

    tx = []
    dm = []
    xlsm = []
    csv = []  # codechange for csv
    xlsb = []  # code change for xlsb

    for i in inputfiles:
        if '.docx' in i and '~' not in i:
            d.append(i)
        if '.pptx' in i and '~' not in i:
            pp.append(i)
        if '.pdf' in i and '~' not in i:
            pdf.append(i)
        if '.doc' in i and '.docx' not in i and '.docm' not in i and '~' not in i:
            d2.append(i)
        if ('.xlsx' in i or '.xls' in i) and ".xlsm" not in i and ".xlsb" not in i and '~' not in i: # code change for xlsb
            xl.append(i)
        if ".xlsb" in i and '~' not in i: # code change for xlsb
            xlsb.append(i)
        if ".xlsm" in i and '~' not in i:
            xlsm.append(i)
        if '.zip' in i and '~' not in i:
            zp.append(i)
        if '.txt' in i and '~' not in i:
            tx.append(i)
        if '.docm' in i and '~' not in i:
            dm.append(i)
        if '.csv' in i and '~' not in i:
            csv.append(i)

    '''
    print("docx %s" % len(d))
    print("pptx %s" % len(pp))
    print("pdf %s" % len(pdf))
    print("doc %s" % len(d2))
    print("xlsx %s" % len(xl))
    print("xlsm %s" % len(xlsm))
    print("xlsb %s" % len(xlsb))  # code change for xlsb
    print("txt %s" % len(tx))
    print("docm %s" % len(dm))
    print("csv %s" % len(csv))  # codechange for csv
    print("zipped %s" % len(zp))
    '''

    global unzip_errors
    unzip_errors = [[], []]

    # Make folder in import directory
    global out, out_legacy

    # out = import_dir + '\\temporary_folder_PIISearch'
    out = "PI Scan\Temporary_folder_PIISearch"
    out_legacy = "PI Scan\Temp2"

    # check If the folder exists
    if os.path.exists(out):
        deleteTempfolder(out)
    else:
        os.mkdir(out)

    if os.path.exists(out_legacy):
        deleteTempfolder(out_legacy)
    else:
        os.mkdir(out_legacy)


    # Unzip and store files
    for i in zp:
        try:

            '''
            
            temp_drive = "a"
            if len(i_temp) >= 260:
                head, tail = os.path.split(i)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i = r'' + temp_drive + ':\\' + tail
            '''

            temp_drive = "b"

            i_temp = i

            if len(i_temp) >= 260:
                head, tail = os.path.split(i)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i_temp = r'' + temp_drive + ':\\' + tail

            head, tail = os.path.split(i_temp)
            file_unzip(i_temp, out + "\\" + tail)


        except Exception as err:
            unzip_errors[0].append(i)
            unzip_errors[1].append(err)
            file = pd.DataFrame(unzip_errors[0], columns=['File'])
            error = pd.DataFrame(unzip_errors[1], columns=['Error'])
            errortype = pd.DataFrame(['Unzip Error'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            pass
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

    # In[19]:

    # Add unzipped files to file lists

    global doc2
    global pp2
    global pdf2
    global d2_2
    global xl2

    global tx2
    global dm2
    global xlsm2
    global xlsb2  # code change for xlsb
    global csv2  # codechange for csv

    doc2 = []
    pp2 = []
    pdf2 = []
    d2_2 = []
    xl2 = []
    tx2 = []
    dm2 = []
    xlsm2 = []
    xlsb2 = []  # code change for xlsb
    csv2 = []  # codechange for csv

    global inputfiles2

    inputfiles2 = walk_through(out)


    # code change for xlsb - see two changes below
    for i in inputfiles2:
        if '.docx' in i and '~' not in i:
            doc2.append(i)
        if '.pptx' in i and '~' not in i:
            pp2.append(i)
        if '.pdf' in i and '~' not in i:
            pdf2.append(i)
        if '.doc' in i and '.docx' not in i and '.docm' not in i and '~' not in i:
            d2_2.append(i)
        if ('.xlsx' in i or '.xls' in i) and ".xlsm" not in i and ".xlsb" not in i and '~' not in i: # code change for xlsb
            xl2.append(i)
        if ".xlsm" in i and '~' not in i:
            xlsm2.append(i)
        if ".xlsb" in i and '~' not in i:
            xlsb2.append(i)
        if '.txt' in i or '.txt' in i and '~' not in i:
            tx2.append(i)
        if '.docm' in i and '~' not in i:
            dm2.append(i)
        # codechange for csv
        if '.csv' in i and '~' not in i:
            csv2.append(i)

    d.extend(doc2)
    pp.extend(pp2)
    pdf.extend(pdf2)
    d2.extend(d2_2)
    xl.extend(xl2)
    tx.extend(tx2)
    dm.extend(dm2)  # adding .docm and .docm in zipped folders
    d.extend(dm)  # adding .docm files to .docx list
    xlsm.extend(xlsm2)  # adding .xlsm files and .xlsm files in zipped folders
    xl.extend(xlsm)  # adding all .xlsm into the actual xl which contains xlsx and xls
    csv.extend(csv2)  # codechange for csv

    xlsb.extend(xlsb2)  # code change for xlsb - adding xlsb and xlsb2
    xl.extend(xlsb)  # code change for xlsb - appending the xlsb files to xl

    global count_doc
    global count_doc_legacy
    global count_pp
    global count_pdf
    global count_xl
    global count_tx
    global count_csv  # codechange for csv
    global count_number_of_images

    global size_doc
    global size_pp
    global size_pdf
    global size_xl
    global size_tx
    global size_csv  # codechange for csv

    count_doc = len(d)
    count_doc_legacy = len(d2)

    count_pp = len(pp)
    count_pdf = len(pdf)
    count_xl = len(xl)
    count_tx = len(tx)
    count_csv = len(csv)  # codechange for csv

    count_number_of_images = 0

    size_doc = 0
    size_pp = 0
    size_pdf = 0
    size_xl = 0
    size_tx = 0
    size_csv = 0  # codechange for csv

    global count_file

    count_file = len(inputfiles) + len(inputfiles2) - len(zp)






# Functions to read Word documents

def gettext(WordTestFile):

    doc = Doc(WordTestFile)
    text = []

    for para in doc.paragraphs:
        # print("PARA" + para)
        text.append(' ' + para.text)

    return ' '.join(text)


def read_table(table):
    data = []
    keys = None
    for i, row in enumerate(table.rows):
        text = (cell.text for cell in row.cells)

        if i == 0:
            keys = tuple(text)
            continue
        row_data = dict(zip(keys, text))
        data.append(row_data)
    return data


def all_table_to_list(document):
    lis = []
    for i in range(0, len(document.tables)):
        df = pd.DataFrame(read_table(document.tables[i]))
        df = pd.DataFrame(np.vstack([df.columns, df]))
        df = pd.Series(df.values.ravel('F'))
        lis = lis + df.values.tolist()
    return lis


# Function to search for a pattern - outputs a dataframe, length restrictions must be applied separately

# ssn = find_pattern(text_data, i, ssn_pattern, "SSN", "social security", "SSN")
# ssn = find_pattern(text_data, file, ssn_pattern, "SSN", "social security", "SSN", xlsx=True)
# china = find_pattern(text_data, i, CHINA_pattern, "RIC", "Resident Identity Card", "Resident Identity Card", xlsx=False)

def find_pattern(data, file, pattern, Keyword1, Keyword2, Name, score, xlsx=False):
    if xlsx == False:

        data = [x for x in data if x != '']

        data1 = []
        data1 = ''.join(data)
        # ptt2 = pd.Series(data1)

        # pt2 = pd.DataFrame(re.findall(pattern, data1), columns=["PII_Extracted"])

        # ptt = pd.Series(data[0])

        pt = pd.DataFrame([file], columns=["File"])
        # pt = pd.DataFrame(re.findall(pattern, data1), columns=["PII_Extracted"])

        temp1_count = 0
        pt["Keyword"] = temp1_count

        # pt = pd.DataFrame(data.astype(str).str.findall(pattern), columns=["PII_Extracted"])

        # print(type(data1))
        # print(re.findall(pattern, data1))

        pt["PII_Extracted"] = [re.findall(pattern, data1)[:5]]
        #pt["PII_Extracted"] = [re.findall(pattern, data1)[:1000]]

        pt["Type"] = Name
        pt["Pattern_or_Keyword"] = "Pattern"
        pt["Score"] = score

        # pt["Keyword1"] = len(re.findall(Keyword1, data, re.IGNORECASE))
        # pt["Keyword2"] = len(re.findall(Keyword2, data, re.IGNORECASE))

        # temp1 = ptt.astype(str).str.findall(Keyword1, flags=re.IGNORECASE)

        # temp2 = ptt.astype(str).str.findall(Keyword2, flags=re.IGNORECASE)

        # temp2_count = 0

        # for x in temp1:
        #    temp1_count += len(x)

        # for x in temp2:
        #    temp2_count += len(x)

        # pt["Keyword2"] = temp2_count



    else:

        pt1 = pd.DataFrame(data.astype(str).str.findall(pattern), columns=["PII_Extracted"])
        # print("DDDDDDDDDDDDDDDDDDDD")

        temp_data = []
        for x in pt1.PII_Extracted:
            for y in x:
                if y != '':
                    temp_data.append(y)

        # print("asdfasdf")
        # print(len(temp_data))

        #pt1 = pd.DataFrame(temp_data[:5], columns=["PII_Extracted"])
        pt1 = pd.DataFrame(temp_data[:1000], columns=["PII_Extracted"])

        # pt1["length"] = [len(str(x)) for x in pt1["PII_Extracted"]]
        # pt1 = pt1[pt1["length"] > 2]
        pt1.dropna(inplace=True)
        t = [[''.join(str(x)) for x in v] for v in pt1["PII_Extracted"]]

        pt = pd.DataFrame([file], columns=["File"])
        temp1_count = 0
        pt["Keyword"] = temp1_count

        # pt = pd.DataFrame([''.join(t[i]) for i in range(len(t))], columns=["PII_Extracted"])

        pt["PII_Extracted"] = [[''.join(t[i]) for i in range(len(t))]]

        pt["Type"] = Name
        pt["Pattern_or_Keyword"] = "Pattern"
        pt["Score"] = score

        # pt["Keyword1"] = sum(sum([x > -1 for x in [data.astype(str).str.find(Keyword1)]]))
        # print(pt["Keyword1"])

        # temp1 = data.astype(str).str.findall(Keyword1, flags=re.IGNORECASE)
        # temp2 = data.astype(str).str.findall(Keyword2, flags=re.IGNORECASE)

        # temp2_count = 0

        # for x in temp1:
        #    temp1_count += len(x)

        # for x in temp2:
        #    temp2_count += len(x)

        # pt["Keyword1"] = sum(len(x) > 0 for x in temp1)

        # pt["Keyword2"] = sum(len(x) > 0 for x in temp2)
        # pt["Keyword2"] = temp2_count

    # print("WWWWWWWWWWWWWWWWWWWWWWW")
    # print(pt.head())

    return pt


# In[24]:


# function to search for a keyword

# newDF = find_Keyword(text, file, k, 'PIIKeyword')
def find_Keyword(data, file, Keyword, Name, score, xlsx=False):
    if xlsx == False:

        data = [x for x in data if x != '']
        # print(data)
        # ptt = pd.Series(data[0])

        # pt = pd.DataFrame(ptt.astype(str).str.findall(pattern), columns=["PII_Extracted"])
        # print(pt)

        # pt["File"] = file
        # pt["Type"] = Name

        ptt = pd.Series(data[0])

        temp1 = ptt.astype(str).str.findall(Keyword, flags=re.IGNORECASE)

        # print(temp1)

        temp1_count = 0

        for x in temp1:
            temp1_count += len(x)

        # pt = pd.DataFrame(ptt.astype(str).str.findall(pattern), columns=["PII_Extracted"])
        # pt = pd.DataFrame(re.findall(Keyword, data, re.IGNORECASE), columns=["PII_Extracted"])
        # pt = pd.DataFrame(ptt.astype(str).str.findall(Keyword), columns=["PII_Extracted"])
        # print("test1")
        pt = pd.DataFrame([file], columns=["File"])
        # print("test2")
        pt["Keyword"] = temp1_count
        pt["PII_Extracted"] = [Keyword]
        # pt = pd.DataFrame([Keyword], columns=["PII_Extracted"])

        pt["Type"] = Name

        # pt["Keyword2"] = 0
        pt["Pattern_or_Keyword"] = "Keyword"
        # pt["Score"] = score * temp1_count
        pt["Score"] = score

        '''
        if temp1_count:
            print("REWQREWQ")
            print(pt["File"])
            print(str(temp1_count) + "   " + Keyword)
        '''



    else:
        # pt1 = pd.DataFrame(data.astype(str).str.findall(Keyword, flags=re.IGNORECASE), columns=["PII_Extracted"])
        # temp1 = data.astype(str).str.findall(Keyword1, flags=re.IGNORECASE)
        # pt = pd.DataFrame([Keyword], columns=["PII_Extracted"])



        #pt1 = pd.DataFrame([Keyword], columns=["PII_Extracted"])
        #pt1["length"] = [len(str(x)) for x in pt1["PII_Extracted"]]
        #pt1 = pt1[pt1["length"] > 2]
        #pt1.dropna(inplace=True)
        #t = [[''.join(str(x)) for x in v] for v in pt1["PII_Extracted"]]
        # pt["PII_Extracted"] = [''.join(t[i]) for i in range(len(t))]

        pt = pd.DataFrame([file], columns=["File"])

        temp1 = data.astype(str).str.findall(Keyword, flags=re.IGNORECASE)

        temp1_count = 0

        for x in temp1:
            temp1_count += len(x)

        # print(re.findall(Keyword, data, re.IGNORECASE))


        pt["Keyword"] = temp1_count


        pt["PII_Extracted"] = [Keyword]

        # pt = pd.DataFrame([''.join(t[i]) for i in range(len(t))], columns=["PII_Extracted"])
        # pt["File"] = file

        pt["Type"] = Name
        pt["Pattern_or_Keyword"] = "Keyword"
        pt["Score"] = score


        # pt["Keyword2"] = 0

        # pt["Score"] = score * temp1_count

    return pt


def predict_encoding(file_path, n_lines=20):
    '''Predict a file's encoding using chardet'''
    import chardet

    # Open the file as binary data
    with open(file_path, 'rb') as f:
        # Join binary lines for specified number of lines
        rawdata = b''.join([f.readline() for _ in range(n_lines)])

    return chardet.detect(rawdata)['encoding']


def readTxt():
    global newDF
    global size_tx
    global Keyword_final
    global pattern_final
    global count_progress
    global current_file

    # Reading Word documents
    start_time = time.time()
    newDF = pd.DataFrame()

    for i in tx:



        current_file = i

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        '''if len(i) >= 560:
            file = pd.DataFrame([i], columns=['File'])
            error = pd.DataFrame(["File length exceeds 260"], columns=['Error'])
            errortype = pd.DataFrame(['Filename Length'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            continue'''
        try:
            i_temp = i

            temp_drive = "b"
            if len(i_temp) >= 260:
                head, tail = os.path.split(i)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i = r'' + temp_drive + ':\\' + tail

            size_tx += os.stat(i).st_size

            if os.stat(i).st_size == 0:
                continue

            if predict_encoding(i) == "UTF-16":
                file1 = open(i, "r", encoding="UTF-16")
            else:
                file1 = open(i, "r")

            text_data = file1.read()

            file1.close()

            text_data = [''.join(text_data)]

            #print(text_data)

            if (text_data != ['']):

                for j in range(len(patterns)):

                    pattern_temp = find_pattern(text_data, i, patterns_regex[j], "SSN", "social security", patterns[j],
                                                patterns_score[j], xlsx=False)

                    pattern_temp["File"] = pattern_temp["File"].replace([i], i_temp)

                    if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                        pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                            header=False, encoding='utf-8-sig')

                    # pattern_final = pattern_final[["PII_Extracted", "File", "Type", "Keyword1", "Keyword2","Pattern_or_Keyword", "Score"]]

                    # pattern_final.head()

                    # pattern_final = pattern_final.append(pattern_temp)

                # New Code
                for k in range(len(Keywords)):

                    newDF = find_Keyword(text_data, i, Keywords[k], Keywords_category[k], Keywords_score[k], xlsx=False)
                    newDF = newDF[newDF.Keyword != 0]
                    # Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
                    # print(newDF.head())

                    newDF["File"] = newDF["File"].replace([i], i_temp)

                    if newDF.index.size > 0:
                        # Keyword_final = Keyword_final.append(newDF)
                        newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                     encoding='utf-8-sig')

                # print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
                '''
                for x in Keyword_final["Keyword"]:
                    if x != 0:
                        print(str(x))
                #print(Keyword_final)
                '''



        except Exception as err:
            # print(err)

            err_list[0].append(i)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Text'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)



            continue
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

            count_progress += 1

    print("--- %s seconds --- scanned %s txt documents --- %s kilobytes" % (
        time.time() - start_time, count_tx, size_tx / 1024))

    Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
    # print(Keyword_final)

# codechange for csv
# this complete function below to read csv documents
# readcsv - updated on 3.5.2021
def readcsv():
    global newDF
    global size_csv
    global Keyword_final
    global pattern_final
    global count_progress
    global current_file

    start_time = time.time()
    newDF = pd.DataFrame()
    # codechange for csv
    for i in csv:

        current_file = i

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        try:
            i_temp = i

            temp_drive = "b"
            if len(i_temp) >= 260:
                head, tail = os.path.split(i)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i = r'' + temp_drive + ':\\' + tail

            size_csv += os.stat(i).st_size



            text_data1 = []

            with open(i, 'r', encoding=predict_encoding(i)) as read_obj:
                #csv_reader = reader(read_obj)

                #x.replace('\0', '') for x in csvfile
                #csvreader = csv.reader(x.replace('\0', '') for x in csvfile)

                csv_reader = reader(x.replace('\0', '') for x in read_obj)
                for row in csv_reader:
                    for eachitem in row:
                        text_data1.append(eachitem)

            text_data = pd.Series(text_data1)

            #if (text_data != ['']):

            for j in range(len(patterns)):

                    pattern_temp = find_pattern(text_data, i, patterns_regex[j], "SSN", "social security", patterns[j],
                                                patterns_score[j], xlsx=True)

                    pattern_temp["File"] = pattern_temp["File"].replace([i], i_temp)

                    if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                        pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                            header=False, encoding='utf-8-sig')


                # New Code
            for k in range(len(Keywords)):

                newDF = find_Keyword(text_data, i, Keywords[k], Keywords_category[k], Keywords_score[k], xlsx=True)
                newDF = newDF[newDF.Keyword != 0]


                newDF["File"] = newDF["File"].replace([i], i_temp)

                if newDF.index.size > 0:
                        # Keyword_final = Keyword_final.append(newDF)
                        newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                     encoding='utf-8-sig')




        except Exception as err:
            # print(err)

            err_list[0].append(i)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Text'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)

            continue
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

            count_progress += 1

    print("--- %s seconds --- scanned %s csv documents --- %s kilobytes" % (
        time.time() - start_time, count_csv, size_csv / 1024))

    #Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
    # print(Keyword_final)

def save_as_docx(path):
    # Opening MS Word
    global out, out_legacy

    new_file_abs = ""

    try:


        word = win32.gencache.EnsureDispatch("Word.Application")
        #word = win32.dynamic.Dispatch('Word.Application')

        path_temp = path

        temp_drive = "b"
        if len(path) >= 260:
            head, tail = os.path.split(path)
            subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/", "\\") + '"', shell=True)
            path_temp = r'' + temp_drive + ':\\' + tail

        # doc = word.Documents.Open(path)
        doc = word.Documents.Open(os.path.abspath(path_temp))
        #doc = word.Documents.Open(r"C:\Python\PI Scan\Input_1\test file 3.docx")

        doc.Activate()

        head, tail = os.path.split(path)

        # Rename path with .docx
        new_file_abs = os.path.abspath(os.path.join(out_legacy,tail))

        new_file_abs = re.sub(r'\.\w+$', '.docx', new_file_abs)

        # this gives some time for win32 / word to prepare before properly processing saveas.
        time.sleep(3)

        # Save and Close
        word.ActiveDocument.SaveAs(
            new_file_abs, FileFormat=constants.wdFormatXMLDocument
            #new_file_abs, FileFormat=constants.wdFormatDocument
        )


        doc.Close(False)
        #word.Quit()



    except Exception as err:
        # print(err)

        err_list[0].append(path)
        err_list[1].append(err)

        file = pd.DataFrame(err_list[0], columns=['File'])
        error = pd.DataFrame(err_list[1], columns=['Error'])
        errortype = pd.DataFrame(['Read Legacy Doc'], columns=['Type'])
        error_report = pd.concat([file, error, errortype], axis=1)

        error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
    finally:
        if len(path) >= 260:
            subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

    return new_file_abs


'''# Converting .doc files to .docx
def convert_doc_docx():
    global doc_errs
    global paths
    global d2
    global d2_temp

    doc_errs = [[], []]
    start_time = time.time()
    # Create list of paths to .doc files
    paths = d2

    global file
    global error
    global df_fnl

    for path in paths:
        try:

            save_as_docx(path)

        except Exception as err:
            doc_errs[0].append(path)
            doc_errs[1].append(err)
            file = pd.DataFrame(doc_errs[0], columns=['File'])
            error = pd.DataFrame(doc_errs[1], columns=['Error'])
            errortype = pd.DataFrame(['Legacy Word DOC'], columns=['Type'])
            df_fnl = pd.concat([file, error, errortype], axis=1)

            df_fnl.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            pass

    print("--- %s seconds --- save doc as docx" % (time.time() - start_time))

    
    d2_temp = [i + "x" for i in d2]

    # turned off DOC scan
    #d.extend(d2)'''

def readWord_Legacy():
    global newDF
    global size_doc
    global Keyword_final
    global pattern_final
    global count_progress
    global current_file
    # global d2 #legacy doc file converted into docx. need to delete these temporary files at the end of readWord()

    numberofimages = 0

    # Reading Word documents
    start_time = time.time()
    newDF = pd.DataFrame()

    for i in d2:



        i2 = save_as_docx(i)


        '''try:
            i2 = save_as_docx(i)
        except Exception as err:

            err_list[0].append(i)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Legacy Word'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)

            count_progress += 1
            continue'''
        # print(i)
        # i = r'%s' % i

        current_file = i

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        try:

            i_temp = i2

            temp_drive = "b"
            if len(i_temp) >= 260:
                head, tail = os.path.split(i2)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i2 = r'' + temp_drive + ':\\' + tail


            size_doc += os.stat(i2).st_size
            size_doc += 1

            if os.stat(i2).st_size == 0:
                continue

            text_data = [gettext(i2)]



            global OCR_flag

            if (OCR_flag.get() == 1):
                # print("used OCR")
                # text += pytesseract.image_to_string(image)
                content = docx2python(i2)
                pytesseract.pytesseract.tesseract_cmd = r'Tesseract-OCR\tesseract.exe'

                for name, imageData in content.images.items():
                    numberofimages += 1
                    stream = BytesIO(imageData)
                    if "png" in name:
                        image = Image.open(stream).convert("RGBA")
                    text = pytesseract.image_to_string(image)
                    text_data.append(text)
                    stream.close()


            # print("YYYYYYYYYYYYYYYYYYYYYYYY")
            # print(text_data)

            document = Doc(i2)

            all_lis = all_table_to_list(document)

            # text_data.append(all_lis)
            text = ','.join(str(''.join(str(x) for x in v)) for v in text_data)
            text = text.lower()
            # text_data.append(text)

            # print(text_data)

            for x in all_lis:
                # print(x)
                # text_data.append(str(x))
                text_data.append(str(x) + " ")

            text_data = [''.join(text_data)]



            if (text_data != ['']):

                for j in range(len(patterns)):

                    pattern_temp = find_pattern(text_data, i2, patterns_regex[j], "SSN", "social security", patterns[j],
                                                patterns_score[j], xlsx=False)

                    #pattern_temp["File"] = pattern_temp["File"].replace([i2], i_temp)
                    pattern_temp["File"] = pattern_temp["File"].replace([i2], i)

                    # pattern_final = pattern_final[["PII_Extracted", "File", "Type", "Keyword1", "Keyword2","Pattern_or_Keyword", "Score"]]
                    # pattern_final.head()
                    # pattern_final = pattern_final.append(pattern_temp)

                    if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                        pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                            header=False, encoding='utf-8-sig')

                # New Code
                for k in range(len(Keywords)):

                    newDF = find_Keyword(text_data, i2, Keywords[k], Keywords_category[k], Keywords_score[k], xlsx=False)
                    newDF = newDF[newDF.Keyword != 0]
                    # print(newDF.head())

                    #newDF["File"] = newDF["File"].replace([i2], i_temp)
                    newDF["File"] = newDF["File"].replace([i2], i)

                    if newDF.index.size > 0:
                        # Keyword_final = Keyword_final.append(newDF)
                        newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                     encoding='utf-8-sig')



                # print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
                '''
                for x in Keyword_final["Keyword"]:
                    if x != 0:
                        print(str(x))
                #print(Keyword_final)
                '''

            os.remove(i2)

        except Exception as err:
            # print(err)

            err_list[0].append(i)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Legacy Word'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)


            continue
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

            count_progress += 1


    print("--- %s seconds --- scanned %s Legacy Word (.doc) documents --- %s kilobytes    --- %s images found" % (
        time.time() - start_time, count_doc_legacy, size_doc / 1024, numberofimages))

    # for x in d2:
    #    os.remove(x)

    Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
    # print(Keyword_final)



def readWord():
    global newDF
    global size_doc
    global Keyword_final
    global pattern_final
    global count_progress
    global current_file
    #global d2 #legacy doc file converted into docx. need to delete these temporary files at the end of readWord()



    numberofimages = 0

    # Reading Word documents
    start_time = time.time()
    newDF = pd.DataFrame()

    for i in d:

        #print(i)
        #i = r'%s' % i


        current_file = i

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        '''if len(i) >= 560:
            file = pd.DataFrame([i], columns=['File'])
            error = pd.DataFrame(["File length exceeds 260"], columns=['Error'])
            errortype = pd.DataFrame(['Filename Length'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            continue'''




        i_temp = i

        temp_drive = "b"
        if len(i_temp) >= 260:
            head, tail = os.path.split(i)
            subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
            i = r'' + temp_drive + ':\\' + tail

        try:
            size_doc += os.stat(i).st_size
            size_doc += 1


            if os.stat(i).st_size == 0:
                continue


            text_data = [gettext(i)]


            global OCR_flag

            if (OCR_flag.get() == 1):
                # print("used OCR")
                # text += pytesseract.image_to_string(image)



                content = docx2python(i)

                pytesseract.pytesseract.tesseract_cmd = r'Tesseract-OCR\tesseract.exe'

                for name, imageData in content.images.items():

                    numberofimages += 1

                    stream = BytesIO(imageData)


                    if "png" in name:
                        image = Image.open(stream).convert("RGBA")


                    text = pytesseract.image_to_string(image)


                    text_data.append(text)
                    stream.close()


            # print("YYYYYYYYYYYYYYYYYYYYYYYY")
            # print(text_data)

            document = Doc(i)

            all_lis = all_table_to_list(document)

            # text_data.append(all_lis)
            text = ','.join(str(''.join(str(x) for x in v)) for v in text_data)
            text = text.lower()
            # text_data.append(text)

            # print(text_data)

            for x in all_lis:
                # print(x)
                # text_data.append(str(x))
                text_data.append(str(x) + " ")

            text_data = [''.join(text_data)]


            if (text_data != ['']):

                for j in range(len(patterns)):

                    pattern_temp = find_pattern(text_data, i, patterns_regex[j], "SSN", "social security", patterns[j],
                                                patterns_score[j], xlsx=False)

                    pattern_temp["File"] = pattern_temp["File"].replace([i], i_temp)

                    # pattern_final = pattern_final[["PII_Extracted", "File", "Type", "Keyword1", "Keyword2","Pattern_or_Keyword", "Score"]]
                    # pattern_final.head()
                    # pattern_final = pattern_final.append(pattern_temp)

                    if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                        pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                            header=False, encoding='utf-8-sig')

                # New Code
                for k in range(len(Keywords)):

                    newDF = find_Keyword(text_data, i, Keywords[k], Keywords_category[k], Keywords_score[k], xlsx=False)
                    newDF = newDF[newDF.Keyword != 0]
                    # print(newDF.head())

                    newDF["File"] = newDF["File"].replace([i], i_temp)

                    if newDF.index.size > 0:
                        # Keyword_final = Keyword_final.append(newDF)
                        newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                     encoding='utf-8-sig')



                # print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
                '''
                for x in Keyword_final["Keyword"]:
                    if x != 0:
                        print(str(x))
                #print(Keyword_final)
                '''
        except Exception as err:
            # print(err)

            err_list[0].append(i_temp)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Word'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)

            continue
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

            count_progress += 1

    print("--- %s seconds --- scanned %s Word documents --- %s kilobytes    --- %s images found" % (
        time.time() - start_time, count_doc, size_doc / 1024, numberofimages))

    #for x in d2:
    #    os.remove(x)

    Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
    # print(Keyword_final)


def extract_images_from_PDF(path):
    global OCR_flag
    text = ''

    if (OCR_flag.get() == 1):

        doc = fitz.open(path)
        # print("GGGGGGGGGGGGGGGGGG")

        for i in range(len(doc)):
            for img in doc.getPageImageList(i):
                xref = img[0]

                # print("aaaaa")
                pix = fitz.Pixmap(doc, xref)
                # print(xref)
                # print(pix)



                if pix.colorspace is not None:
                    pix = fitz.Pixmap(fitz.csRGB, pix)


                '''if pix.n >= 5:
                    print("44")
                    pix = fitz.Pixmap(fitz.csRGB, pix)'''

                '''
                if pix.n < 5:  # this is GRAY or RGB
                    pix.writePNG("p%s-%s.png" % (i, xref))
                else:  # CMYK: convert to RGB first
                    pix1 = fitz.Pixmap(fitz.csRGB, pix)
                    #pix1.writePNG("p%s-%s.png" % (i, xref))
                    pix1 = None
                pix = None
                '''

                image = Image.open(io.BytesIO(pix.getImageData()))

                pytesseract.pytesseract.tesseract_cmd = r'Tesseract-OCR\tesseract.exe'

                # pytesseract.pytesseract.tesseract_cmd = 'C:\\Python\\Tesseract-OCR\\tesseract.exe'



                # print("used OCR")
                text += pytesseract.image_to_string(image)
                # else:
                #    print("did not use OCR")


        doc.close()

    return text


# Reading PDFs

def convert_pdf_to_txt(path):
    '''Convert pdf content from a file path to text

    :path the file path
    '''
    rsrcmgr = PDFResourceManager()
    codec = 'utf-8'
    laparams = LAParams()

    with io.StringIO() as retstr:
        with TextConverter(rsrcmgr, retstr, codec=codec,
                           laparams=laparams) as device:
            with open(path, 'rb') as fp:
                interpreter = PDFPageInterpreter(rsrcmgr, device)
                password = ""
                maxpages = 0
                # caching = True
                caching = False
                pagenos = set()

                for page in PDFPage.get_pages(fp,
                                              pagenos,
                                              maxpages=maxpages,
                                              password=password,
                                              caching=caching,
                                              check_extractable=False):
                    interpreter.process_page(page)

                return retstr.getvalue()


def readPDF():
    global newDF
    global size_pdf
    global count_number_of_images
    global pattern_final
    global Keyword_final
    global OCR_flag
    global count_progress
    global current_file

    start_time = time.time()
    newDF = pd.DataFrame()

    for i in pdf:

        current_file = i

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        '''if len(i) >= 560:
            file = pd.DataFrame([i], columns=['File'])
            error = pd.DataFrame(["File length exceeds 260"], columns=['Error'])
            errortype = pd.DataFrame(['Filename Length'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            continue'''

        try:

            i_temp = i

            temp_drive = "b"

            if len(i_temp) >= 260:
                head, tail = os.path.split(i)

                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                i = r'' + temp_drive + ':\\' + tail


            size_pdf += os.stat(i).st_size

            if os.stat(i).st_size == 0:
                continue

            #####################################################
            # text_data = convert_pdf_to_txt(i)

            # pdfFileObj = open(i, 'rb')
            # text_data=slate.PDF(pdfFileObj)

            count_patterns = 0
            pt = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"])
            newDF = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"])

            infile = open(i, 'rb')

            count_n = 0


            for page in PDFPage.get_pages(infile, check_extractable=False):

                if count_patterns >= 10:
                    break
                output = io.StringIO()
                manager = PDFResourceManager()
                converter = TextConverter(manager, output, laparams=LAParams())
                interpreter = PDFPageInterpreter(manager, converter)
                interpreter.process_page(page)

                converter.close()
                text_data = output.getvalue()

                count_n += 1



                # print("-------------------------------------------------------")
                # print(text)
                output.close()

                # text_data = [x.replace('\n', '') for x in text_data]
                #text = ''.join(str(''.join(str(x) for x in v)) for v in text_data)
                text = ''.join(str(''.join(str(x) for x in v)) for v in text_data)

                #print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAA %s", str(count_n))
                #print(text)


                # print("aaaaa")
                # print(text)
                # print(type(text_image))

                if (OCR_flag.get() == 1):
                    doc = fitz.open(i)
                    for temp_i in range(len(doc)):
                        for img in doc.getPageImageList(temp_i):
                            count_number_of_images += 1
                    text_data_image = extract_images_from_PDF(i)
                    text_data_image = [x.replace('\n', '') for x in text_data_image]
                    text_image = ''.join(str(''.join(str(x) for x in v)) for v in text_data_image)

                    text += text_image

                text = text.lower()

                if text == [""]:
                    count_progress += 1
                    continue
                # print(i)
                # print(text)

                # print("PDFPDFPDF")
                # print([text])

                # Search for patterns

                # print(text)

                for j in range(len(patterns)):
                    pattern_temp = find_pattern(text, i, patterns_regex[j], "SSN", "social security", patterns[j],
                                                patterns_score[j],
                                                xlsx=False)
                    count_patterns += len(pattern_temp["PII_Extracted"].tolist()[0])

                    pattern_temp["File"] = pattern_temp["File"].replace([i], i_temp)

                    if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                        pt = pt.append(pattern_temp, ignore_index=True)

                    # if(len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                    #    pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                    #                    header=False, encoding='utf-8-sig')

                # for k in Keywords:
                #    Keyword_final.append(find_Keyword(text,i,k, "PIIKeyword"))
                #
                # New Code
                for k in range(len(Keywords)):
                    newDF_temp = find_Keyword([text], i, Keywords[k], Keywords_category[k], Keywords_score[k])

                    newDF_temp = newDF_temp[newDF_temp.Keyword != 0]

                    newDF_temp["File"] = newDF_temp["File"].replace([i], i_temp)

                    if newDF_temp.index.size > 0:
                        # Keyword_final = Keyword_final.append(newDF)
                        newDF = newDF.append(newDF_temp, ignore_index=True)

                        # newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False, encoding='utf-8-sig')


            infile.close()

            # print(len(pt["PII_Extracted"]))

            pt_temp = pd.DataFrame(columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"])

            pt = pt.sort_values(by=["Type"])
            unique_type = pd.unique(pt["Type"])

            newDF = newDF.sort_values(by=["PII_Extracted"])
            unique_type2 = pd.unique(newDF["PII_Extracted"])

            for t1 in unique_type:
                temp_PII = []
                temp_score = 0
                for t2 in range(len(pt)):
                    if (pt.iloc[t2][3] == t1):
                        temp_PII = temp_PII + pt.iloc[t2][2]
                        temp_score = pt.iloc[t2][5]
                pt_temp2 = [[i_temp, 0, temp_PII, t1, "Pattern", temp_score]]

                pt_temp3 = pd.DataFrame(pt_temp2,
                                        columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword",
                                                 "Score"])

                # pt.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,header=False, encoding='utf-8-sig')
                pt_temp3.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                encoding='utf-8-sig')

            for t1 in unique_type2:
                temp_keyword = 0
                temp_type = ""
                temp_score = 0
                for t2 in range(len(newDF)):
                    if (newDF.iloc[t2][2] == t1):
                        temp_keyword = temp_keyword + newDF.iloc[t2][1]
                        temp_type = newDF.iloc[t2][3]
                        temp_score = newDF.iloc[t2][5]
                newDF_temp2 = [[i_temp, temp_keyword, t1, temp_type, "Keyword", temp_score]]

                newDF_temp3 = pd.DataFrame(newDF_temp2,
                                           columns=["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword",
                                                    "Score"])

                newDF_temp3.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False, header=False,
                                   encoding='utf-8-sig')


        except Exception as err:
            # print(err)
            err_list[0].append(i_temp)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read PDF'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)

            count_progress += 1

            continue
        finally:
            if len(i_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

        count_progress += 1

    # print("--- %s seconds --- scanned %s PDF documents --- %s kilobytes   --- %s images converted" % (time.time() - start_time, count_pdf, size_pdf/1024, count_number_of_images))
    print("--- %s seconds --- scanned %s PDF documents --- %s kilobytes   --- %s images found" % (
        time.time() - start_time, count_pdf, size_pdf / 1024, count_number_of_images))


def readPPT():
    # Read PPTs

    global size_pp
    global Keyword_final
    global pattern_final
    global newDF
    global count_progress
    global current_file

    number_of_images = 0

    start_time = time.time()
    newDF = pd.DataFrame()
    l = len(pp)

    for file in pp:

        current_file = file

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        '''if len(file) >= 560:
            filename = pd.DataFrame([file], columns=['File'])
            error = pd.DataFrame(["File length exceeds 260"], columns=['Error'])
            errortype = pd.DataFrame(['Filename Length'])
            error_report = pd.concat([filename, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            continue'''

        text_data = []
        try:

            file_temp = file

            temp_drive = "b"
            if len(file_temp) >= 260:
                head, tail = os.path.split(file)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                file = r'' + temp_drive + ':\\' + tail

            size_pp += os.stat(file).st_size

            if os.stat(file).st_size == 0:
                continue

            prs = Presentation(file)


            for slide in prs.slides:
                for shape in slide.shapes:

                    global OCR_flag

                    if (OCR_flag.get() == 1):
                        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                            number_of_images += 1

                            image_bytes = shape.image.blob
                            stream = BytesIO(image_bytes)
                            image = Image.open(stream).convert("RGBA")

                            pytesseract.pytesseract.tesseract_cmd = r'Tesseract-OCR\tesseract.exe'

                            temp_image_text = pytesseract.image_to_string(image)
                            stream.close()

                            text_data.append(temp_image_text)

                    if hasattr(shape, "text"):
                        for paragraph in shape.text_frame.paragraphs:
                            for run in paragraph.runs:
                                text_data.append(run.text)

                    if shape.has_table:
                        for r in shape.table.rows:
                            for c in r.cells:
                                text_data.append(c.text_frame.text)


                    else:
                        continue

            text = ','.join(str(''.join(str(x) for x in v)) for v in text_data)
            text = text.lower()

            if text == "":
                count_progress += 1
                continue
            # print("OOOOOOOOOOOOOOOOOOOOO")
            # print([text])
            # Search for patterns

            for j in range(len(patterns)):
                pattern_temp = find_pattern([text], file, patterns_regex[j], "SSN", "social security", patterns[j],
                                            patterns_score[j],
                                            xlsx=False)

                pattern_temp["File"] = pattern_temp["File"].replace([file], file_temp)

                if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                    pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                        header=False,
                                        encoding='utf-8-sig')
                # pattern_final = pattern_final[["PII_Extracted", "File", "Type", "Keyword1", "Keyword2","Pattern_or_Keyword", "Score"]]
                # pattern_final.head()

                # pattern_final = pattern_final.append(pattern_temp)

            # New Code

            for k in range(len(Keywords)):


                newDF = find_Keyword([text], file, Keywords[k], Keywords_category[k], Keywords_score[k])

                newDF = newDF[newDF.Keyword != 0]


                newDF["File"] = newDF["File"].replace([file], file_temp)

                if newDF.index.size > 0:
                    # Keyword_final = Keyword_final.append(newDF)
                    newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                 header=False, encoding='utf-8-sig')





        except Exception as err:
            err_list[0].append(file)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read PPTX'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)



            continue
        finally:
            if len(file_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

            count_progress += 1

    print("--- %s seconds --- scanned %s PPTX documents --- %s kilobytes    --- %s images found" % (
        time.time() - start_time, count_pp, size_pp / 1024, number_of_images))


'''
def get_excel_text(path):
    sheet_data = []
    workbook = xlrd.open_workbook(path, on_demand=True)

    for i in range(workbook.nsheets):
        for j in range(workbook.sheet_by_index(i).ncols):
            for k in range(workbook.sheet_by_index(i).nrows):
                if workbook.sheet_by_index(i).cell(k, j).value != xlrd.empty_cell.value:
                    sheet_data.append(workbook.sheet_by_index(i).cell(k, j).value)
    return pd.Series(sheet_data)
'''

# code change for xlsb - include this entire function below which reads xlsb text data
def readxlsbformat(path):

    sheet_data = []
    wb = open_xlsb(path)
    sheet_data = [item.v for x in wb.sheets for row in wb.get_sheet(x).rows() for item in row if item.v != None]
    del wb
    pdobj = pd.Series(sheet_data)

    return pdobj


def get_excel_text(path):
    sheet_data = []
    err1 = ""

    try:
        workbook = xlrd.open_workbook(path, on_demand=True)

        for i in range(workbook.nsheets):

            for j in range(workbook.sheet_by_index(i).ncols):

                for k in range(workbook.sheet_by_index(i).nrows):

                    if workbook.sheet_by_index(i).cell(k, j).value != xlrd.empty_cell.value:
                        sheet_data.append(workbook.sheet_by_index(i).cell(k, j).value)

        workbook.release_resources()

        del workbook


    except:
        sheet_data = []


        #err1 = pd.DataFrame([path], columns=['File'])
        #err2 = pd.DataFrame(["Entire sheet (all columns and rows) is merged in this spreadsheet."], columns=['Error'])
        #err3 = pd.DataFrame(["Excel Text"], columns=["Type"])
        #error_report = pd.concat([err1,err2,err3], axis=1)
        #print(error_report)
        #error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)





    try:
        global OCR_flag
        global number_of_images_excel

        #excel = win32.gencache.EnsureDispatch('Excel.Application')
        #excel = win32.Dispatch("Excel.Application")



        # https://stackoverflow.com/questions/47608506/issue-in-using-win32com-to-access-excel-file


        if (OCR_flag.get() == 1):
            #excel = win32.dynamic.Dispatch('Excel.Application')
            excel = win32com.client.gencache.EnsureDispatch()

            workbook = excel.Workbooks.Open(path, None, True)

            pytesseract.pytesseract.tesseract_cmd = r'Tesseract-OCR\tesseract.exe'

            for sheet in workbook.Worksheets:
                for i, shape in enumerate(sheet.Shapes):
                    if shape.Name.startswith("Picture"):

                        number_of_images_excel += 1
                        shape.Copy()
                        image = ImageGrab.grabclipboard()

                        if image is None:
                            temp_count = 0
                            while image is None:
                                temp_count += 1
                                if temp_count > 10:
                                    break

                                image = ImageGrab.grabclipboard()
                        image_bytes = io.BytesIO()

                        image.save(image_bytes, format="PNG")

                        image = Image.open(image_bytes).convert("RGBA")
                        temp_sheet_data = pytesseract.image_to_string(image)
                        sheet_data.append(temp_sheet_data)

                    # print(image_bytes.getvalue())

                    # print(BytesIO(image))
                    # sheet_data.append(pytesseract.image_to_string(image))

                    # image.close()
            workbook.Close(False)
            #excel.Quit()

    except AttributeError as err:

        file = pd.DataFrame([path], columns=['File'])
        error = pd.DataFrame([err], columns=['Error'])
        errortype = pd.DataFrame(['Excel Text'], columns=['Type'])
        error_report = pd.concat([file, error, errortype], axis=1)

        error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)



    return pd.Series(sheet_data)


# Reading Excel files

def readExcel():
    global newDF
    global Keyword_final
    global pattern_final
    global size_xl
    global count_progress
    global current_file

    global number_of_images_excel

    number_of_images_excel = 0

    start_time = time.time()
    newDF = pd.DataFrame()
    # pattern_final = pd.DataFrame()

    for file in xl:


        current_file = file

        # mainwindow.after(0, lambda: T3.configure(state="normal"))
        mainwindow.after(0, lambda: T3.delete("1.0", "end"))
        mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
        # mainwindow.after(0, lambda: T3.configure(state="disabled"))

        '''if len(file) >= 560:
            filename = pd.DataFrame([file], columns=['File'])
            error = pd.DataFrame(["File length exceeds 260"], columns=['Error'])
            errortype = pd.DataFrame(['Filename Length'])
            error_report = pd.concat([filename, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)
            continue'''

        # start_time1 = time.time()

        try:

            file_temp = file

            temp_drive = "b"
            if len(file_temp) >= 260:
                head, tail = os.path.split(file)
                subprocess.call(r'subst ' + temp_drive + ': ' + '"' + head.replace("/","\\") + '"', shell=True)
                file = r'' + temp_drive + ':\\' + tail

            size_xl += os.stat(file).st_size

            if os.stat(file).st_size == 0:
                continue

                #print(file)



            if '.xlsb' in file and '~' not in file:
                text_data =  readxlsbformat(file)
            else:
                text_data = get_excel_text(file)


            #text = text_data.to_string()

            #text = text.lower()


            # Search for patterns
            for j in range(len(patterns)):

                pattern_temp = find_pattern(text_data, file, patterns_regex[j], "SSN", "social security", patterns[j],
                                            patterns_score[j],
                                            xlsx=True)

                pattern_temp["File"] = pattern_temp["File"].replace([file], file_temp)

                # pattern_final = pattern_final[["PII_Extracted", "File", "Type", "Keyword1", "Keyword2","Pattern_or_Keyword", "Score"]]
                # pattern_final.head()

                # pattern_final = pattern_final.append(pattern_temp)

                if (len(pattern_temp["PII_Extracted"].tolist()[0]) > 0):
                    pattern_temp.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                        header=False,
                                        encoding='utf-8-sig')



            temp_i = 0

            # New Code
            for k in range(len(Keywords)):


                newDF = find_Keyword(text_data, file, Keywords[k], Keywords_category[k], Keywords_score[k], xlsx=True)

                newDF = newDF[newDF.Keyword != 0]
                # print("888888888888888888888888888888")
                # print(newDF)


                newDF["File"] = newDF["File"].replace([file], file_temp)

                if newDF.index.size > 0:
                    # Keyword_final = Keyword_final.append(newDF)

                    newDF.to_csv(r'PI Scan\Output Data\Final_Output-temp.csv', mode="a", index=False,
                                 header=False, encoding='utf-8-sig')

            # print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBB")
            # Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
            # print(Keyword_final)




        except Exception as err:
            # print(err)
            err_list[0].append(file)
            err_list[1].append(err)

            file = pd.DataFrame(err_list[0], columns=['File'])
            error = pd.DataFrame(err_list[1], columns=['Error'])
            errortype = pd.DataFrame(['Read Excel'], columns=['Type'])
            error_report = pd.concat([file, error, errortype], axis=1)

            error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)

            continue
        finally:
            count_progress += 1

            if len(file_temp) >= 260:
                subprocess.call(r'subst ' + temp_drive + ': /D', shell=True)

    print("--- %s seconds --- scanned %s Excel documents --- %s kilobytes    --- %s images found" % (
        time.time() - start_time, count_xl, size_xl / 1024, number_of_images_excel))


# Final Output
def generateFinalOutput():
    global pattern_final
    global final_list
    global Keyword_final

    # print(final_list.head())

    pattern_final.columns = ["PII_Extracted", "File", "Type", "Keyword1", "Keyword2", "Pattern_or_Keyword", "Score"]

    pattern_final = pattern_final[
        ["PII_Extracted", "File", "Type", "Keyword1", "Keyword2", "Pattern_or_Keyword", "Score"]]
    pattern_final.head()

    pattern_final["Keyword1"] = pattern_final["Keyword1"] + pattern_final["Keyword2"]

    pattern_final = pattern_final[pattern_final.PII_Extracted != '']
    pattern_final.drop(["Keyword2"], axis=1, inplace=True)
    pattern_final.columns = ["PII_Extracted", "File", "Type", "Keyword", "Pattern_or_Keyword", "Score"]
    pattern_final = pattern_final[["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"]]
    pattern_final.head()

    pattern_final = pattern_final.sort_values(by=["File", "Type", "PII_Extracted"])

    # print(pattern_final.head())
    final_list = final_list.append(pattern_final)
    # print(final_list.head())

    # print(Keyword_final.head())
    Keyword_final = Keyword_final[Keyword_final.Keyword != 0]
    # print(Keyword_final.head())
    Keyword_final.columns = ["PII_Extracted", "File", "Type", "Keyword", "Keyword2", "Pattern_or_Keyword", "Score"]
    Keyword_final = Keyword_final[["File", "Keyword", "PII_Extracted", "Type", "Pattern_or_Keyword", "Score"]]
    Keyword_final.head()

    final_list = final_list.append(Keyword_final)

    Keyword_final = Keyword_final.sort_values(by=["File", "Type", "PII_Extracted"])

    # unique_keywords_found = final_list["PII_Extracted"].values.tolist()

    unique_keywords_found = Keyword_final.PII_Extracted.unique()

    unique_patterns_found = pattern_final.Type.unique()
    # print(Keyword_final.PII_Extracted)

    final_list = pattern_final.append(Keyword_final)

    # final_list.to_csv(r'C:\Python\PI Scan\Output Data\Final_Output.csv', index=False)
    final_list.to_csv(r'PI Scan\Output Data\Final_Output.csv', index=False, encoding='utf-8-sig')

    # Display number of files by file type

    filelist = final_list.File.unique().tolist()
    filelist2 = []

    count_after_doc = 0
    count_after_pp = 0
    count_after_pdf = 0
    count_after_xls = 0
    count_after_csv = 0  # codechange for csv

    for i in filelist:
        if ".docx" in i and '~' not in i:
            count_after_doc += 1
        if '.pptx' in i and '~' not in i:
            count_after_pp += 1
        if '.pdf' in i and '~' not in i:
            count_after_pdf += 1
        if ('.xlsx' in i or '.xls' in i or '.xlsm' in i or '.xlsb' in i) and '~' not in i: # code change for xlsb
            count_after_xls += 1
        # codechange for csv
        if '.csv' in i and '~' not in i:
            count_after_csv += 1

    # print(Path(filelist[0]).suffix)

    # print(filelist2)


def generateOutputSummary():
    final_list = pd.read_csv(r'PI Scan\Output Data\Final_Output-temp.csv')

    filelist = final_list.File.unique().tolist()
    filelist2 = []

    count_after_doc = 0
    count_after_pp = 0
    count_after_pdf = 0
    count_after_xls = 0
    count_after_tx = 0
    count_after_csv = 0  # codechange for csv

    # code change for xlsb
    for i in filelist:
        if (".docx" in i or ".docm" in i) and '~' not in i:
            count_after_doc += 1
        if '.pptx' in i and '~' not in i:
            count_after_pp += 1
        if '.pdf' in i and '~' not in i:
            count_after_pdf += 1
        if ('.xlsx' in i or '.xls' in i or '.xlsm' in i or '.xlsb' in i) and '~' not in i: # code change for xlsb
            count_after_xls += 1
        if '.txt' in i and '~' not in i:
            count_after_tx += 1
        # codechange for csv
        if '.csv' in i and '~' not in i:
            count_after_csv += 1

    # codechange for csv - add CSV updates in all three rows in txt_summary
    # please note csv variables added to below txt_summary
    txt_summary = (["File Type ->", "Word", "PPT", "PDF", "Excel", "Text", "CSV", "Total"],
                   ["# of Files Identified", count_doc+count_doc_legacy, count_pp, count_pdf, count_xl, count_tx,count_csv,
                    count_doc + count_doc_legacy + count_pp + count_pdf + count_xl + count_tx + count_csv],
                   ["# of Files containing PI", count_after_doc, count_after_pp, count_after_pdf, count_after_xls,
                    count_after_tx, count_after_csv,
                    count_after_doc + count_after_pp + count_after_pdf + count_after_xls + count_after_tx + count_after_csv])

    import csv
    myfile = open(r'PI Scan\Output Data\Final_Output_Summary.csv', "w+", newline='')

    with myfile:
        write = csv.writer(myfile)
        write.writerows(txt_summary)

    myfile.close()

    # txt_summary.to_csv(r'C:\Python\PI Scan\Output Data\Final_Output_Summary.csv', index=False, encoding='utf-8-sig')


def generateDashboard():
    cb_data = pd.read_csv(r"PI Scan\Output Data\Final_Output.csv")

    # Moving the dashboard file from template to Output folder with date time attached

    dashboard_name = "PI Scan\Output Data\Python Privacy Tool - Dashboard"
    dashboard_name1 = "PI Scan\Templates\Python Privacy Tool - Dashboard_v2.xlsx"
    now = datetime.now()
    # mm/dd/YY H:M:S
    dt_string = now.strftime("%m-%d-%Y %H_%M_%S")
    dashboard_name = dashboard_name + "_" + dt_string

    dashboard_name = dashboard_name + ".xlsx"
    print(dashboard_name)

    shutil.copy(dashboard_name1, dashboard_name)

    # In[36]:

    print("Code for writing into new dashboard")
    from xlwt import Workbook
    import xlsxwriter
    import openpyxl

    loc = dashboard_name
    Last_wb = openpyxl.load_workbook(loc)

    worksheet = Last_wb['Repository #']
    temp_string = ""

    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)

    colx = 8
    rowx = 14

    df_file = pd.unique(cb_data["File"])
    df_file = final_list.sort_values("File")
    df_file = pd.unique(df_file["File"])
    df_length = df_file.size

    for i in range(df_length):
        # print("XXXXXXXXXXXXXXX")
        # print(df_file[i])
        fileref = worksheet.cell(rowx + i, 2)
        fileref.value = df_file[i]
        print(df_file[i])

    # print(unique_patterns_found)

    print(pattern_final.set_index(["File", "PII_Extracted"]).count(level="File"))

    # db_pattern_final = pattern_final.set_index(["File", "PII_Extracted"]).count(level="File")

    rowx_i = 14
    rowx_j = 0

    col_start_patterns = 0
    col_end_patterns = 0
    col_start_keywords = 0
    col_end_keywords = 0

    worksheet.cell(rowx - 2, colx).value = "Patterns Found"

    col_start_patterns = colx

    for i in range(len(unique_patterns_found)):
        worksheet.cell(rowx - 1, colx + i).value = unique_patterns_found[i]
        col_end_patterns = colx + len(unique_patterns_found)

    colx = colx + len(unique_patterns_found)
    col_start_keywords = colx

    worksheet.cell(rowx - 2, colx).value = "Keywords Found"
    for i in range(len(unique_keywords_found)):
        worksheet.cell(rowx - 1, colx + i).value = unique_keywords_found[i]
        col_end_keywords = colx + len(unique_keywords_found)

    while worksheet.cell(rowx_i, 2).value != None:
        # print(db_pattern_final.loc[db_pattern_final["File"] == worksheet.cell(rowx_i, 2).value])
        # print(len(pattern_final.loc[pattern_final["File"] == worksheet.cell(rowx_i, 2).value].index))
        # print(pattern_final.loc[pattern_final["File"] == worksheet.cell(rowx_i, 2).value].index)
        for i in range(col_end_patterns - col_start_patterns):
            worksheet.cell(rowx_i, col_start_patterns + i).value = \
                len(pattern_final.loc[(pattern_final["File"] == worksheet.cell(rowx_i, 2).value) & (
                            pattern_final["Type"] == worksheet.cell(rowx - 1, col_start_patterns + i).value)])
            print("1234")

        for i in range(col_end_keywords - col_start_keywords):
            # worksheet.cell(rowx_i, col_start_keywords+i).value = \
            #    Keyword_final.loc[(Keyword_final["File"] == worksheet.cell(rowx_i, 2).value) & (Keyword_final["PII_Extracted"] == worksheet.cell(rowx-1, col_start_keywords+i).value)]
            temp_value = Keyword_final.loc[(Keyword_final["File"] == worksheet.cell(rowx_i, 2).value) & (
                        Keyword_final["PII_Extracted"] == worksheet.cell(rowx - 1,
                                                                         col_start_keywords + i).value)].Keyword.values
            if len(temp_value) != 0:
                print(temp_value[0])
                worksheet.cell(rowx_i, col_start_keywords + i).value = temp_value[0]

            # worksheet.cell(rowx_i, col_start_keywords+i).value = Keyword_final.loc[(Keyword_final["File"] == worksheet.cell(rowx_i, 2).value) & (Keyword_final["PII_Extracted"] == worksheet.cell(rowx-1, col_start_keywords+i).value)].Keyword.values
            # worksheet.cell(rowx_i, col_start_keywords + i).value = temp_value
            # print(temp_df["PII_Extracted"])
            # print(col_end_keywords, col_start_keywords)
        # print(pattern_final.loc[pattern_final["File"] == worksheet.cell(rowx_i, 2).value])
        # worksheet.cell(rowx_i, )
        # print(rowx_i)
        rowx_i += 1

    Last_wb.save(loc)

    '''
    # Replacing blank spaces from column names
    cb_data.columns = cb_data.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('(', '').str.replace(
        ')',
        '')

    # merging based on file name
    df_file = pd.unique(cb_data["file"])

    # Initialize list with 0 as initial value and size as same as that of unique file names/path

    df_length = df_file.size
    keywords_size = len(Keywords)
    # print(keywords_size)
    lcount_SSN = [0] * df_length
    lcount_PIL = [0] * df_length
    Sum_SSN = [0] * df_length
    Sum_PIL = [0] * df_length
    PII_Count = 0
    Score = [0] * df_length
    var_score = 0
    var_rating = 0
    Rating = [0] * df_length
    Address = [0] * df_length
    Birth = [0] * df_length
    col_names = ['address']
    main_df = pd.DataFrame(index=range(df_length), columns=Keywords)
    main_df = main_df.fillna(0)
    # print(main_df)

    '''

    '''
    # Calculate total count of Dataframe items
    cb_length = cb_data.index.size

    # Code to calculate SSN number and sum of SSNs

    for i in range(df_length):
        PII_Count = 0
        for j in range(cb_length):
            if (cb_data['file'][j] == df_file[i]):
                if (cb_data['type'][j] == "SSN"):
                    lcount_SSN[i] = lcount_SSN[i] + 1
                    Sum_SSN[i] = cb_data['keyword'][j]
                    # print(Sum_SSN[i])
                if (cb_data['type'][j] == "PIIKeyword"):
                    for k in range(keywords_size):
                        temp = 0
                        if (cb_data['pii_extracted'][j].lower().strip() == Keywords[k].lower().strip()):
                            # print(cb_data['pii_extracted'][j].lower().strip())

                            # print(type(temp))
                            # print(temp)
                            # print(type(cb_data['keyword'][j]))
                            # print(cb_data['keyword'][j])
                            temp = temp + int(cb_data['keyword'][j])
                            main_df.loc[i, Keywords[k]] = temp

    # In[33]:

    # Code for concatenate appropriate fields together

    Dup_List1 = [['social security', 'ssn'],
                 ['voter id', 'voting card'],
                 ['phone number', 'contact number'],
                 ['date of birth', 'birth date'],
                 ['date of death', 'death date'],
                 ['gender', 'sex'],
                 ['education', 'qualification'],
                 ['credit card number', 'debit card number'],
                 ['vehicle id', 'vehicle number', 'license number', 'driving license'],
                 ['employer id', 'employer number'],
                 ['state identification number', 'state id'],
                 ['tax identification number', 'tax id'],
                 ['tribal identification number', 'tribal id'],
                 ['financial account number', 'bank account'],
                 ['policy number', 'policy id'],
                 ['tax information', 'tax return', 'tax number'],
                 ['civil', 'criminal'],
                 ['employment records', 'compensation', 'salary'],
                 ['digital signature', 'private key'],
                 ['religious', 'religion'],
                 ['racial', 'ethnic'],
                 ['geolocation', 'latitude', 'longitude', 'geotag'],
                 ['device number', 'imei', 'mac address'],
                 ['retinal', 'iris scan'],
                 ['facial', 'images', 'photo', 'pictures'],
                 ['national identification number', 'national id', 'government id', 'registration number',
                  'resident identity', 'identification card', 'identity card', 'citizenship id'],
                 ['blood test', 'rbc', 'wbc', 'hgb', 'pneumonia', 'enlarged heart', 'congestive heart failure',
                  'lung mass',
                  'fractures', 'fluid around the lung', 'pleural effusion', 'air around the lung', 'pneumothorax',
                  'emphysema', 'tuberculosis', 'x-ray test results', 'mental conditions', 'anxiety disorders',
                  'panic disorders', 'bipolar disorder', 'depression', 'eating disorders', 'schizophrenia',
                  'substance abuse', 'substance addiction', 'health condition', 'arthritis', 'heart disease', 'cancer',
                  'respiratory diseases', 'alzheimer\'s disease', 'osteoporosis', 'diabetes', 'influenza', 'obesity',
                  'oral health', 'shingles', 'pregnant', 'disease', 'diagnosis', 'x ray', 'prescription', 'drug',
                  'medicine', 'medication', 'medical', 'appendectomy', 'biopsy', 'carotid endarterectomy', 'surgery',
                  'cesarean section', 'cholecystectomy', 'coronary artery bypass', 'debridement',
                  'dilation and curettage',
                  'anesthesia', 'illness', 'health', 'surgic', 'surger', 'lab\'s test', 'lab test', 'medical test',
                  'physical condition', 'mental condition', 'disability']]
    list_of_or = []

    Dup_List1_len = len(Dup_List1)

    main_df.columns = map(str.lower, main_df.columns)
    main_df.columns = main_df.columns.str.strip()
    # print(main_df)

    # Code to combine different keywords as mentioned above together
    for i in range(Dup_List1_len):
        newList = Dup_List1[i]
        temp_sum = 0
        # for t in range(df_length):
        concat_string = ""
        concat_string = newList[0]

        for j in range(len(newList)):
            if (j != 0):
                concat_string = concat_string + " or " + newList[j]
                # print(concat_string)
        list_of_or.append(concat_string)

    df_or = pd.DataFrame(index=range(df_length), columns=list_of_or)
    df_or = df_or.fillna(0)

    # print(df_or)

    df_or2 = pd.concat([main_df, df_or], axis=1)

    # Combining new list with existing list

    for ll in range(Dup_List1_len):
        tt = re.split(" or ", list_of_or[ll])
        for pp in range(len(tt)):
            df_or2[list_of_or[ll]] = df_or2[list_of_or[ll]] + df_or2[tt[pp]]

    # print(Sum_SSN)

    rem_dup_list = []
    for i in Dup_List1:
        rem_dup_list += i

    # print (rem_dup_list)
    for i in range(len(rem_dup_list)):
        # df_or2.drop(columns=rem_dup_list[i])
        # print(df_or2[rem_dup_list[i]])
        df_or2 = df_or2.drop(rem_dup_list[i], axis=1)

    # Positioning social security number or ssn together

    df_or2['social security number or ssn'] = np.array(Sum_SSN)
    cols = df_or2.columns.tolist()
    cols = cols[-1:] + cols[:-1]
    df_or2 = df_or2[cols]
    # print(df_or2)

    df_or2.rename(columns={
        'blood test or rbc or wbc or hgb or pneumonia or enlarged heart or congestive heart failure or lung mass or fractures or fluid around the lung or pleural effusion or air around the lung or pneumothorax or emphysema or tuberculosis or x-ray test results or mental conditions or anxiety disorders or panic disorders or bipolar disorder or depression or eating disorders or schizophrenia or substance abuse or substance addiction or health condition or arthritis or heart disease or cancer or respiratory diseases or alzheimer\'s disease or osteoporosis or diabetes or influenza or obesity or oral health or shingles or pregnant or disease or diagnosis or x ray or prescription or drug or medicine or medication or medical or appendectomy or biopsy or carotid endarterectomy or surgery or cesarean section or cholecystectomy or coronary artery bypass or debridement or dilation and curettage or anesthesia or illness or health or surgic or surger or lab\'s test or lab test or medical test or physical condition or mental condition or disability': 'Protected Health Information or Disease or diagnosis or Blood Test or X Ray or Prescription or Drug or Medicine or Medication or Medical or Illness or Health or Surgic or Surger or Lab\'s or Lab test or medical test or Physical Condition or mental condition or disability'},
        inplace=True)

    # In[34]:

    #KeywordTemplate_data = pd.read_excel('C:\Python\PI Scan\Templates\Keywords Short Name.xlsx')

    # print(len(KeywordTemplate_data.index))

    # print(df_or2.columns[5])
    for i in range(df_or2.columns.size):
        for j in range(len(KeywordTemplate_data.index)):

            if (df_or2.columns[i].lower().strip() == KeywordTemplate_data['Keywords to be searched in Each File'][
                j].lower().strip()):
                df_or2.rename(columns={df_or2.columns[i]: KeywordTemplate_data['Short name for dashboard'][j]},
                              inplace=True)
                # print(KeywordTemplate_data['Shortname'][j])
    # print(df_or2.columns)

    # In[35]:

    # Moving the dashboard file from template to Output folder with date time attached

    dashboard_name = "C:\Python\PI Scan\Output Data\Python Privacy Tool - Dashboard"
    dashboard_name1 = "C:\Python\PI Scan\Templates\Python Privacy Tool - Dashboard.xlsx"
    now = datetime.now()
    # mm/dd/YY H:M:S
    dt_string = now.strftime("%m-%d-%Y %H_%M_%S")
    dashboard_name = dashboard_name + "_" + dt_string

    dashboard_name = dashboard_name + ".xlsx"
    print(dashboard_name)

    shutil.copy(dashboard_name1, dashboard_name)

    # In[36]:

    print("Code for writing into new dashboard")
    from xlwt import Workbook
    import xlsxwriter
    import openpyxl

    loc = dashboard_name
    Last_wb = openpyxl.load_workbook(loc)

    worksheet = Last_wb['Repository #']
    temp_string = ""

    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)

    colx = 13
    rowx = 14

    for i in range(df_length):
        # print("XXXXXXXXXXXXXXX")
        # print(df_file[i])
        fileref = worksheet.cell(rowx + i, 2)
        fileref.value = df_file[i]

    # Writing data into dashboard
    mk_file_col_counter = 0
    for p in range(df_length):
        for j in range(len(df_or2.columns)):
            mk_file_col_counter = 0
            while True:

                temp_string = worksheet.cell(13, 13 + mk_file_col_counter).value
                if (temp_string != None):
                    if (df_or2.columns[j].lower().strip() == temp_string.lower().strip()):
                        mk_file_write_ptr = worksheet.cell(rowx + p, colx + mk_file_col_counter)
                        mk_file_write_ptr.value = df_or2[df_or2.columns[j]][p]
                    # print("wrote")
                mk_file_col_counter = mk_file_col_counter + 1
                # print("ASDFASDF-AAAA")
                # print(temp_string)
                if (temp_string == None):
                    break

    Last_wb.save(loc)

    # In[37]:

    print("Please wait....")

    loc = dashboard_name
    Last_wb = openpyxl.load_workbook(loc)

    loc2 = "C:\Python\PI Scan\Templates\Keywords Short Name.xlsx"
    Last_wb2 = openpyxl.load_workbook(loc2)
    pd_ShortName = pd.read_excel(loc2)
    Shortname_loopCounter = 0

    len_ShortName = len(pd_ShortName.index)

    worksheet = Last_wb['Repository #']
    worksheet2 = Last_wb2['Sheet1']

    temp_string = ""
    temp_string2 = ""
    temp_weight = 0
    scores = []
    temp_score = 0
    mk_file_col_counter = 0
    mk_file_shortname_counter = 0

    colx1 = 13
    rowx1 = 14

    colx2 = 4
    rowx2 = 3

    # Print SSN in code

    for i in range(df_length):
        ssnref = worksheet.cell(rowx1 + i, colx2 + 4)
        ssnref.value = lcount_SSN[i]

    # Calculate total length of avilable Shortnames in Keywords shortnames file
    for i in range(len_ShortName):
        if (worksheet2.cell(2 + i, colx2).value != None):
            Shortname_loopCounter = Shortname_loopCounter + 1
            # print(worksheet2.cell(2+i, colx2).value)
        if (worksheet2.cell(2 + i, colx2).value == None):
            continue

    # Calculate range of iteration values in Dashboard."2 is used for Shortname sheet"

    worksheet_counter = 0
    Dasboard_loopCounter = 0

    while True:
        # print("uuo",worksheet.cell(13, 13+worksheet_counter).value)
        if (worksheet.cell(13, 13 + worksheet_counter).value != None):
            Dasboard_loopCounter = Dasboard_loopCounter + 1
            worksheet_counter = worksheet_counter + 1

        else:
            break

    # print("Please Wait....")

    # Code for adding to Scores array
    for p in range(df_length):
        temp_score = 0

        for j in range(Dasboard_loopCounter):
            temp_string = worksheet.cell(13, 13 + j).value
            mk_file_shortname_counter = 0
            for m in range(Shortname_loopCounter):
                temp_weight = 0

                temp_string2 = worksheet2.cell(3 + m, 4).value

                if (temp_string2 == temp_string):
                    if (int(worksheet.cell(14 + p, 13 + j).value) > 0):
                        temp_weight = worksheet2.cell(3 + m, 2).value
                        temp_score = temp_score + temp_weight

        scores.append(temp_score)

    # Code to put dataa from Score Array to Dashboard

    for i in range(df_length):
        scoreref = worksheet.cell(14 + i, 4)
        if (lcount_SSN[i] > 0):
            scores[i] = scores[i] + 100
        scoreref.value = scores[i]

    # Code to Calculate Tier

    count_tier1 = 0
    count_tier2 = 0
    count_tier3 = 0
    count_tier4 = 0

    for i in range(df_length):
        tierref = worksheet.cell(14 + i, 3)
        if (scores[i] > 100):
            tierref.value = "Tier 1"
            count_tier1 += 1
        if (scores[i] <= 100 and scores[i] >= 20):
            tierref.value = "Tier 2"
            count_tier2 += 1
        if (scores[i] > 1 and scores[i] <= 19):
            tierref.value = "Tier 3"
            count_tier3 += 1
        if (scores[i] >= 0 and scores[i] <= 1):
            tierref.value = "Tier 4"
            count_tier4 += 1

    worksheet.cell(9, 3).value = count_tier1
    worksheet.cell(9, 4).value = count_tier2
    worksheet.cell(9, 5).value = count_tier3
    worksheet.cell(9, 6).value = count_tier4
    worksheet.cell(9, 7).value = count_tier1 + count_tier2 + count_tier3 + count_tier4

    # Display number of files by file type

    worksheet.cell(9, 10).value = count_doc
    worksheet.cell(9, 11).value = count_pp
    worksheet.cell(9, 12).value = count_pdf
    worksheet.cell(9, 13).value = count_xl
    worksheet.cell(9, 14).value = count_doc + count_pp + count_pdf + count_xl

    print("Processing Completed")

    # In[38]:

    # Code for creating list
    tag_list = [
        ['Government-Issued Identification Numbers', 'Social Security Number', 'National ID', 'Voter ID',
         'China National ID', 'Hong Kong National ID', 'Japan National ID', 'S. Korea National ID',
         'Mexico National ID',
         'Malaysia National ID', 'Australia Citizenship ID', 'Tax ID', 'Employer ID', 'Passport', 'Visa', 'State ID',
         'Tribal ID', 'Military ID', 'Vehicle ID'],
        ['Financial Information', 'Debit / Credit Card', 'Account Number', 'Tax Return', 'Policy Number'],
        ['General Identification and Contact Information', 'Name', 'Home Address', 'Email Address', 'Phone Number',
         'Date of Birth', 'Date of Death', 'Employee ID', 'Death Certificate', 'Marriage Certificate',
         'Birth Certificate',
         'Gender', 'Mother\'s Name'],
        ['Sensitive Information', 'Protected Health Information', 'Civil or Criminal', 'Digital Signature',
         'Education / Qualification', 'Compensation', 'Trade Union', 'Religious or Religion', 'Political',
         'Racial or Ethnic', 'Sexual Orientation '],
        ['Technical Identifiers', 'Geolocation', 'IMEI / MAC Address', 'IP Address', 'Password', 'Security Token'],
        ['Biometric Identifiers', 'Fingerprint', 'Genetic', 'Retinal or Iris', 'Voice', 'Images'],
    ]
    tag_list_len = len(tag_list)

    # print("tag_list_len->", tag_list_len)

    tag_list_heads = ['Government-Issued Identification Numbers', 'Financial Information',
                      'General Identification and Contact Information', 'Sensitive Information',
                      'Technical Identifiers',
                      'Biometric Identifiers']

    # New Dataframe for putting checkmarks
    tags_df = pd.DataFrame(index=range(df_length), columns=tag_list_heads)
    tags_df = tags_df.fillna(0)

    print("Logic for putting checkmark")

    '''

    '''
    for m in range(df_length):
        for i in range(tag_list_len):
            newList = tag_list[i]
            # temp_sum = 0
            for j in range(len(newList)):
                if (j != 0):
                    #print("AADDAADDAADD")
                    #print(type(df_or2[newList[j]][m]))
                    #print(df_or2[newList[j]][m])
                    #print("JJJJJJJJJJJJJJJJJJJJJJ")
                    #print(df_or2['Passport'])
                    #print(newList)
                    if (int(df_or2[newList[j]][m]) > 0):
                        tags_df[newList[0]][m] = 1
                        break;
    '''

    # print("AAAAAAAAAAAAAAAAAAAAA - show tags_df")
    # print(tags_df)

    # In[39]:

    tick_row = 0
    tick_col = 0
    # Writing checks into dashboard

    '''
    for p in range(df_length):
        temp_string1 = ""
        for j in range(Dasboard_loopCounter + 1):
            temp_string1 = worksheet.cell(tick_row + 13, tick_col + 12 + j).value
            #print("temp_str", temp_string1)
            if (temp_string1 != None):

                for m in range(tag_list_len):
                    # print("tags_df_column[m]",tags_df.columns[m])
                    if tags_df.columns[m].strip() == temp_string1.strip():
                        #print("match")
                        tickref = worksheet.cell(14 + p, 12 + j)
                        if (tags_df[temp_string1][p] == 1):
                            tickref.value = 'a'

    print("writing result into file")
    Last_wb.save(loc)
    Last_wb2.save("C:\Python\PI Scan\Templates\Keywords Short Name.xlsx")

    #input('Press Enter to exit')

    # In[40]:

    # Store Errors

    file = pd.DataFrame(err_list[0], columns=['File'])
    error = pd.DataFrame(err_list[1], columns=['error'])
    df_fnl = pd.concat([file, error], axis=1)

    df_fnl.to_csv(r'C:\Python\PI Scan\Output Data\errors_1.csv')

    '''

def OptionMenu_SelectionEvent(event):
    # every time dropdown menu is selected, it will trigger this function.

    #save configuration with the option selected
    global variable
    global language_set
    global language_data

    global button1, button2, button3, button4, button5, button6

    setting = variable.get()

    f = open(r"PI Scan\Configuration\config.txt", "w", encoding="utf-16")
    f.write(setting)
    f.close()
    #update the language

    language_data = []
    for i in language_set.values.tolist():
        if i[0] == setting:
            language_data = i


    button1.config(text=language_data[21])
    button2.config(text=language_data[22])
    button3.config(text=language_data[19])
    button4.config(text=language_data[23])
    button5.config(text=language_data[20])
    button6.config(text=language_data[24])

    global label_step1_1, label_step1_2, label_step2_1, label_step2_2, label_step3_1, label_step3_2, label_step4_1, label_step4_2, label_step5_1, label_step5_2, label_step6_1, label_step6_2
    global label_description_1, label_description_2, label_consideration_1, label_consideration_2, label_instruction_1, label_instruction_2, label_footnote

    label_step1_1.config(text=language_data[7])
    label_step1_2.config(text=language_data[8])
    label_step2_1.config(text=language_data[9])
    label_step2_2.config(text=language_data[10])
    label_step3_1.config(text=language_data[11])
    label_step3_2.config(text=language_data[12])
    label_step4_1.config(text=language_data[13])
    label_step4_2.config(text=language_data[14])
    label_step5_1.config(text=language_data[15])
    label_step5_2.config(text=language_data[16])
    label_step6_1.config(text=language_data[17])
    label_step6_2.config(text=language_data[18])

    label_description_1.config(text=language_data[1])
    label_description_2.config(text=language_data[2])
    label_consideration_1.config(text=language_data[3])
    label_consideration_2.config(text=language_data[4])
    label_instruction_1.config(text=language_data[5])
    label_instruction_2.config(text=language_data[6])
    label_footnote.config(text=language_data[25])




def read_languagefile():
    global languages
    global language_set

    language_set = pd.read_excel(r"PI Scan\Configuration\Language.xlsx", sheet_name="Language")

    languages = [i[0] for i in language_set.values.tolist()]


def createUI():
    global mainwindow
    global label_step1_1, label_step1_2, label_step2_1, label_step2_2, label_step3_1, label_step3_2, label_step4_1, label_step4_2, label_step5_1, label_step5_2, label_step6_1, label_step6_2
    global label_description_1, label_description_2, label_consideration_1, label_consideration_2, label_instruction_1, label_instruction_2, label_footnote

    mainwindow.title("PI Scanner")

    mainwindow.configure(bg="white")
    mainwindow.configure(bg="white")

    image = Image.open(r"lib\MetLife logo.png")
    image = image.resize((225, 60))
    photo = ImageTk.PhotoImage(image)

    img_label = tkinter.Label(image=photo)
    img_label.image = photo

    img_label.config(bg="white")
    img_label.grid(row=1, column=5, columnspan=3, sticky=(W))

    font_type = "Georgia"

    

    tkinter.Label(mainwindow, text="Version 0.91", bg="white", font=(font_type, 12), anchor="e").grid(row=2, column=5, sticky="e")

    # tkinter.Label(mainwindow, text="Version 0.95").grid(row=0)
    # tkinter.Label(mainwindow, text="Description").grid(row=1)
    label_description_1 = tkinter.Label(mainwindow, text="Description:", bg="deep sky blue", font=(font_type, 11), borderwidth=2,
                  relief="solid")
    label_description_1.grid(row=1, column=0, sticky=(N, S, E, W), padx=10, pady=2)

    label_description_2 = tkinter.Label(mainwindow,
                  text="PI Scanner is designed to scan user-defined patterns and keywords \nfrom unstructured data such as PDF, Excel, PowerPoint, Word, TXT, etc.",
                  justify="left", bg="white", font=(font_type, 10))
    label_description_2.grid(row=1, column=1, columnspan=3, sticky="w")

    label_consideration_1 = tkinter.Label(mainwindow, text="Privacy Considerations:", bg="deep sky blue", font=(font_type, 11), borderwidth=2,
                  relief="solid")
    label_consideration_1.grid(row=2, column=0, sticky=(N, S, E, W), padx=10, pady=2)

    label_consideration_2 = tkinter.Label(mainwindow,
                  text="Follow the MetLife's Global Privacy Policy and APP guidelines regarding PI handling.",
                  bg="white", font=(font_type, 10))
    label_consideration_2.grid(row=2, column=1, columnspan=3,
                                                         sticky="w")
    # Follow the MetLife's Global Privacy Policy and APP guidelines regarding PI handling.
    tkinter.Label(mainwindow, text="", bg="white", font=(font_type, 12)).grid(row=3, column=0, sticky="w")
    label_instruction_1 = tkinter.Label(mainwindow, text="Instructions", bg="yellow green", font=(font_type, 11), borderwidth=2,
                  relief="solid")
    label_instruction_1.grid(row=4, column=0, sticky=(N, S, E, W), padx=10, pady=2)

    label_instruction_2 = tkinter.Label(mainwindow, text="To run the tool, follow the steps below:", bg="white", font=(font_type, 12))
    label_instruction_2.grid(row=4, column=2, columnspan=2, sticky="w")

    label_step1_1 = tkinter.Label(mainwindow, text="Step 1:", bg="gainsboro", font=(font_type, 12), width=7)
    label_step1_1.grid(row=5, column=1,
          sticky=(N, S, E, W))

    label_step2_1 = tkinter.Label(mainwindow, text="Step 2: ", bg="white", font=(font_type, 12), width=7)
    label_step2_1.grid(row=6, column=1, sticky=(N, S, E, W))

    label_step3_1 = tkinter.Label(mainwindow, text="Step 3: ", bg="gainsboro", font=(font_type, 12), width=7)
    label_step3_1.grid(row=7, column=1, sticky=(N, S, E, W))

    label_step4_1 = tkinter.Label(mainwindow, text="Step 4: ", bg="white", font=(font_type, 12), width=7)
    label_step4_1.grid(row=9, column=1, sticky=(N, S, E, W))

    label_step5_1 = tkinter.Label(mainwindow, text="Step 5: ", bg="gainsboro", font=(font_type, 12), width=7)
    label_step5_1.grid(row=11, column=1, sticky=(N, S, E, W))

    label_step6_1 = tkinter.Label(mainwindow, text="Step 6: ", bg="white", font=(font_type, 12), width=7)
    label_step6_1.grid(row=12, column=1, sticky=(N, S, E, W))

    label_footnote = tkinter.Label(mainwindow, text="Footnote - Open handbook if you need more details:", bg="white", font=(font_type, 12), anchor="e")
    label_footnote.grid(row=14, column=1, sticky=(N,S,E,W), columnspan=2)

    '''
    def callback(event):
        webbrowser.open_new(event.widget.cget("text"))
    
    link1 = Label(root, text="Google Hyperlink", fg="blue", cursor="hand2")
    link1.pack()
    link1.bind("<Button-1>", lambda e: callback("http://www.google.com"))
    
    link2 = Label(root, text="Ecosia Hyperlink", fg="blue", cursor="hand2")
    link2.pack()
    link2.bind("<Button-1>", lambda e: callback("http://www.ecosia.org"))
    '''

    label_link = tkinter.Label(mainwindow, text="Link", bg="white",font=(font_type, 12), fg="#0000FF", anchor="w", underline=True)
    label_link.grid(row=14, column=3, sticky=(N, S, E, W))
    label_link.configure(underline=True)
    #label_link.bind("<Button-1>", lambda e: callback("http://www.google.com"))
    label_link.bind("<Button-1>", lambda e: callback(r"Handbook\\"))

    tkinter.Label(mainwindow, text="", bg="white", font=(font_type, 12)).grid(row=9, column=0, sticky="w")

    label_step1_2 = tkinter.Label(mainwindow, text="Click button to choose keyword and patterns that \nyou want the tool to search for.",
                  bg="gainsboro", font=(font_type, 10), height=2, justify="left", anchor="w")
    label_step1_2.grid(row=5, column=2, sticky=(N, S, W, E))

    label_step2_2 = tkinter.Label(mainwindow,
                  text="Check the box to scan images in the documents.\n(Note: Image Scanning will significantly increase scanning time.)",
                  bg="white", font=(font_type, 10), height=2, justify="left", anchor="w")
    label_step2_2.grid(row=6, column=2, sticky="w", pady=10)

    label_step3_2 = tkinter.Label(mainwindow,
                  text="Click button to select a drive / folder to search in.\nIt will also scan subfolders.",
                  bg="gainsboro", font=(font_type, 10), justify="left", anchor="w", height=2)
    label_step3_2.grid(row=7, column=2, sticky=(N, S, W, E))

    label_step4_2 = tkinter.Label(mainwindow, text="Click on run button to start the scanning.\nSee progress below.", justify="left", anchor="w", bg="white", font=(font_type, 10))
    label_step4_2.grid(row=9, column=2, sticky="w")

    label_step5_2 = tkinter.Label(mainwindow, text="Click button to open blank Excel dashboard\n(Open Excel Dashboard and click button at top to populate \nthe dashboard and save copy of output files.)",
                  bg="gainsboro", height=4, font=(font_type, 10), justify="left", anchor="w")
    label_step5_2.grid(row=11, column=2, sticky=(N, S, W, E))

    label_step6_2 = tkinter.Label(mainwindow,
                  text="Click button to open a folder where copy of output files are stored.",
                  bg="white", font=(font_type, 10), justify="left", anchor="w")
    label_step6_2.grid(row=12, column=2, sticky=(N, S, W, E))


    #global label1
    global label2


    #label1 = tkinter.Label(mainwindow)
    #label1.grid(row=9, column=3, sticky="w")
    #label1.configure(text = "")

    label2 = tkinter.Label(mainwindow, height=2, width=50, borderwidth=1, justify="left", anchor="w", relief="solid", wraplength=450)
    label2.grid(row=10, column=2, sticky="e", padx=50, pady=10)
    label2.configure(text = "")



    #label1.config(text="Time Elapsed: 00:00:00:00")
    label2.config(text="Total # of files: " + str(0) + "   # of files scanned: " + str(
            0) + "   Percentage: " + "{:.0f}%".format(0) + "\nTime Elapsed: 00:00:00:00")


    #global T, T2
    global T2

    #T = tkinter.Label(mainwindow, height=9, width=30, borderwidth=1, relief="solid", wraplength=200)
    #T.grid(row=7, column=4, columnspan=2, rowspan=2, sticky="w", padx=5)

    T2 = tkinter.Text(mainwindow, height=5, width=25, relief="solid")

    scroll_bar_2 = tkinter.Scrollbar(mainwindow, command=T2.yview, orient="vertical")
    scroll_bar_2.grid(row=7, column=6, sticky=(N,S,W,E))
    T2.configure(yscrollcommand=scroll_bar_2.set, state="disabled")
    T2.grid(row=7, column=4, columnspan=2, sticky=(N,S,W,E),pady=1)

    #recyclebin_location = textbox_recyclebin.get("1.0", "end-1c")
    #if (recyclebin_location == ""):

    #global T3, label3
    global T3

    T3 = tkinter.Text(mainwindow, height=5, width=25, relief="solid")
    scroll_bar_3 = tkinter.Scrollbar(mainwindow, command=T3.yview, orient="vertical")
    scroll_bar_3.grid(row=9, column=6, sticky=(N,S,W,E))
    #T3.configure(yscrollcommand=scroll_bar_3.set, state="disabled")
    T3.configure(yscrollcommand=scroll_bar_3.set)
    T3.grid(row=9, column=4, columnspan=2, sticky=(N,S,W,E),pady=1)

    '''
    label3 = tkinter.Label(mainwindow, height=9, width=30, borderwidth=1, justify="left", relief="solid",
                           wraplength=200)
    label3.grid(row=9, column=4, columnspan=2, rowspan=2, sticky="w", padx=5, pady=10)
    label3.config(text="", anchor="nw")'''

    '''
        if len(temp_recyclebin_location) > 0:
        recyclebin_location = temp_recyclebin_location
        root.after(0, lambda: textbox_recyclebin.delete("1.0", "end"))
        root.after(0, lambda: textbox_recyclebin.insert("1.0", recyclebin_location))
    '''


    global button1, button2, button3, button4, button5, button6

    tkinter.Label(mainwindow, text="", bg="white", font=(font_type, 12)).grid(row=13, column=0, sticky="w")

    button1 = tkinter.Button(mainwindow, text='Select a folder', command=selectfolder)
    button1.grid(row=7,column=3,sticky=(N, S, W, E), padx=10, pady=4)

    button2 = tkinter.Button(mainwindow, text='Run', command=thread_scan)
    button2.grid(row=9,column=3,sticky=(N, S, W, E), padx=10, pady=8)

    button3 = tkinter.Button(mainwindow, text='Keyword & Patterns', command=openConfigurationFile)
    button3.grid(row=5, column=3,sticky=(N, S, W, E),padx=10, pady=4)

    button4 = tkinter.Button(mainwindow, text='Open a new Dashboard', command=openDashboardFile)
    button4.grid(row=11, column=3,sticky=(N, S, W, E), padx=10,pady=4)

    button6 = tkinter.Button(mainwindow, text='Open Output Folder', command=openOutputFolder)
    button6.grid(row=12, column=3, sticky=(N, S, W, E), padx=10, pady=4)


    global OCR_flag

    button5 = tkinter.Checkbutton(mainwindow, text="Enable Image Scan", variable=OCR_flag, borderwidth=1, relief="raised")
    button5.grid(row=6, column=3, sticky=(N, S, W, E), padx=10, pady=4)

    button5.config(state=tkinter.DISABLED)
    # print(OCR_flag.get())


    read_languagefile()

    global OPTIONS
    global variable
    global languages
    global language_set
    global language_data

    option_selected = ""


    f = open(r"PI Scan\Configuration\config.txt", "r", encoding="utf-16")

    option_selected = f.read()

    f.close()

    language_data = []
    for i in language_set.values.tolist():
        if i[0] == option_selected:
            language_data = i

    button1.config(text=language_data[21])
    button2.config(text=language_data[22])
    button3.config(text=language_data[19])
    button4.config(text=language_data[23])
    button5.config(text=language_data[20])
    button6.config(text=language_data[24])

    label_step1_1.config(text=language_data[7])
    label_step1_2.config(text=language_data[8])
    label_step2_1.config(text=language_data[9])
    label_step2_2.config(text=language_data[10])
    label_step3_1.config(text=language_data[11])
    label_step3_2.config(text=language_data[12])
    label_step4_1.config(text=language_data[13])
    label_step4_2.config(text=language_data[14])
    label_step5_1.config(text=language_data[15])
    label_step5_2.config(text=language_data[16])
    label_step6_1.config(text=language_data[17])
    label_step6_2.config(text=language_data[18])

    label_description_1.config(text=language_data[1])
    label_description_2.config(text=language_data[2])
    label_consideration_1.config(text=language_data[3])
    label_consideration_2.config(text=language_data[4])
    label_instruction_1.config(text=language_data[5])
    label_instruction_2.config(text=language_data[6])
    label_footnote.config(text=language_data[25])


    '''
    Format of Language file (language_data):
        [Index 0] Language
        [Index 1] Description_1
        [Index 2] Description_2
        [Index 3] Consideration_1
        [Index 4] Consideration_2
        [Index 5] Instruction_1
        [Index 6] Instruction_2
        [Index 7] Step1_1
        [Index 8] Step1_2
        [Index 9] Step2_1
        [Index 10] Step2_2
        [Index 11] Step3_1
        [Index 12] Step3_2
        [Index 13] Step4_1
        [Index 14] Step4_2
        [Index 15] Step5_1
        [Index 16] Step5_2
        [Index 17] Step6_1
        [Index 18] Step6_2
        [Index 19] Button_1
        [Index 20] Button_2
        [Index 21] Button_3
        [Index 22] Button_4
        [Index 23] Button_5
        [Index 24] Button_6
        [Index 25] Footnote
        [Index 26] Cur_Scan
    '''

    variable = StringVar(mainwindow)
    variable.set(option_selected)

    #dropdown = OptionMenu(mainwindow, variable, *OPTIONS, command = OptionMenu_SelectionEvent)
    dropdown = OptionMenu(mainwindow, variable, *languages, command=OptionMenu_SelectionEvent)
    dropdown.grid(row=3,column=5, sticky=(N,S,W,E), padx=10, pady=4)

    image2 = Image.open(r"lib\MetLife Line.png")
    image2 = image2.resize((1050, 20))
    photo2 = ImageTk.PhotoImage(image2)

    img_label2 = tkinter.Label(image=photo2)
    img_label2.image = photo2

    img_label2.config(bg="white")
    img_label2.grid(row=16, columnspan=6)

    mainwindow.protocol("WM_DELETE_WINDOW", terminate_thread)




    global threadState
    global runState
    runState = 0
    threadState = 1

    thread1 = threading.Thread(target=thread_time, daemon=True)
    thread2 = threading.Thread(target=initiateScan, daemon=True)
    thread1.start()
    thread2.start()

    mainwindow.mainloop()
    thread1.join()
    thread2.join()

def callback(url):
    webbrowser.open_new(url)

def thread_time():
    global runState
    global import_dir
    #global label1
    global label2
    global mainwindow
    global start_time_overall
    global count_file
    global count_progress
    global current_file
    global time_output
    global languages
    global language_set
    global language_data

    start_time_overall = time.time()

    import_dir = ""

    count_file = 0

    current_file = ""


    #t = 0

    while threadState == 1:
        time.sleep(0.5)
        #print("aaaa" + import_dir)
        if runState == 1:

            time_elapsed = time.time() - start_time_overall

            time_output = time_f(time_elapsed)
            #print(time_output)
            #mainwindow.after(0, lambda: label1.config(text="Time Elapsed:  " + time_output))

            #mainwindow.after(0, lambda: label3.config(text="Currently Scanning:  \n" + current_file, anchor="nw"))

            #mainwindow.after(0, lambda: label3.config(text=language_data[26] + "\n" + current_file, anchor="nw"))

            #mainwindow.after(0, lambda: T3.configure(state="normal"))
            #mainwindow.after(0, lambda: T3.delete("1.0", "end"))
            #mainwindow.after(0, lambda: T3.insert("1.0", language_data[26] + "\n" + current_file))
            #mainwindow.after(0, lambda: T3.configure(state="disabled"))

            #mainwindow.after(0, lambda: label1.config(text=time_elapsed))

            if count_file != 0:
                mainwindow.after(0, lambda: label2.config(text="Total # of files: " + str(count_file) + "   # of files scanned: " + str(count_progress) + "   Percentage: " + "{:.0f}%".format(count_progress/count_file * 100) + "\nTime Elapsed: " + time_output))

        #t += 1

def time_f(t_secs):
    try:
        val = int(t_secs)
    except ValueError:
        return "!!!ERROR: ARGUMENT NOT AN INTEGER!!!"
    pos = abs( int(t_secs) )
    day = pos / (3600*24)
    rem = pos % (3600*24)
    hour = rem / 3600
    rem = rem % 3600
    mins = rem / 60
    secs = rem % 60
    res = '%02d:%02d:%02d:%02d' % (day, hour, mins, secs)

    return res

def thread_scan():
    global runState
    global threadState
    global import_dir
    global count_progress
    global language_data

    count_progress = 0

    file_opened = 0


    try:
        f1 = open(r'PI Scan\Output Data\Final_Output_Summary.csv', "w+", newline='')
        f1.close()
    except:
        file_opened = 1

    try:
        f2 = open(r'PI Scan\Output Data\Final_Output-temp.csv', "w+", newline='')
        f2.close()
    except:
        file_opened = 2

    try:
        f3 = open(r'PI Scan\Output Data\Error Report.csv', "w+", newline='')
        f3.close()
    except:
        file_opened = 3

    if len(import_dir) > 0:
        if file_opened == 1:
            messagebox.showerror(title="Error",
                                 message=language_data[28])
        elif file_opened == 2:
            messagebox.showerror(title="Error",
                                 message=language_data[29])
        elif file_opened == 3:
            messagebox.showerror(title="Error",
                                 message=language_data[30])
        else:
            runState = 1
    else:
        messagebox.showerror(title="Error", message="The folder to scan was not selected. Please select a folder to scan.")

def terminate_thread():
    global threadState

    threadState = 0
    sys.exit()

def openDashboardFile():
    # path = os.getcwd()
    #os.startfile(r'PI Scan\Output Data\Final_Output-temp.csv')
    if os.path.exists(r'PI Scan\Output Data\Dashboard.xlsm'):
        os.startfile(r'PI Scan\Output Data\Dashboard.xlsm')
    else:
        messagebox.showerror(title="Error", message="The dashboard template does not exist. Please restore the dashboard template by re-installing the tool.")

def openOutputFolder():
    # path = os.getcwd()
    #os.startfile(r'PI Scan\Output Data\Final_Output-temp.csv')

    if os.path.exists(r'PI Scan\Output Data\Saved Files'):
        os.startfile(r'PI Scan\Output Data\Saved Files')
    else:
        messagebox.showerror(title="Error", message="The folder <Saved Files> does not exist. Please restore the folder by re-installing the tool.")



def openConfigurationFile():
    # path = os.getcwd()
    os.startfile(r'PI Scan\Templates\Keywords Short Name.xlsx')


def deleteTempfolder(folder):
    errormsg = ""
    try:
        shutil.rmtree(folder)

    except OSError as e:
        print("Error: %s : %s" % (out, e.strerror))
        errormsg = e.strerror
        file = pd.DataFrame([out], columns=['File'])
        error = pd.DataFrame([errormsg], columns=['Error'])
        errortype = pd.DataFrame(['Delete Temp Folder'], columns=['Type'])
        error_report = pd.concat([file, error, errortype], axis=1)

        error_report.to_csv(r'PI Scan\Output Data\Error Report.csv', mode="a", index=False, header=False)


def initiateScan():
    global OCR_flag
    global runState
    global threadState
    global start_time_overall
    global count_progress
    global count_file
    global current_file
    global out
    global button1, button2, button3, button4, button5, button6
    global label2
    #global label3
    global time_output
    global language_data

    time_output = ""

    while threadState == 1:
        if runState == 1:

            button1.config(state=tkinter.DISABLED)
            button2.config(state=tkinter.DISABLED)
            button3.config(state=tkinter.DISABLED)
            button4.config(state=tkinter.DISABLED)
            button5.config(state=tkinter.DISABLED)
            button6.config(state=tkinter.DISABLED)

            start_time_overall = time.time()
            count_progress = 0
            count_file = 0
            current_file = ""

            definepattern()
            definekeywords()
            if initializeDatasets() == -1:
                button1.config(state=tkinter.NORMAL)
                button2.config(state=tkinter.NORMAL)
                button3.config(state=tkinter.NORMAL)
                button4.config(state=tkinter.NORMAL)
                #button5.config(state=tkinter.NORMAL)
                button6.config(state=tkinter.NORMAL)
                #label3.config(text="Error", anchor="nw")

                mainwindow.after(0, lambda: T3.configure(state="normal"))
                mainwindow.after(0, lambda: T3.delete("1.0", "end"))
                mainwindow.after(0, lambda: T3.insert("1.0", "Error"))
                mainwindow.after(0, lambda: T3.configure(state="disabled"))

                messagebox.showerror(title="Error",
                                     message="The output file is open by another process. Please close it before running the scan.")
                runState = 0
            else:
                execute_walk_through()
                list_files()
                #convert_doc_docx()

                readWord()
                readWord_Legacy()
                readTxt()

                readPPT()

                readcsv()  # codechange for csv

                readPDF()
                readExcel()

                # generateFinalOutput()

                generateOutputSummary()



                #global excel
                #excel.Quit()
                #print(excel)

                #global mainwindow

                #tkinter.Label(mainwindow,
                #              text="docx " + str(len(d)) + "   pptx " + str(len(pp)) + "   pdf " + str(len(pdf)) + "\ndoc " + str(
                #                  len(d2)) + "   xlsx " + str(len(xl)) + "   txt " + str(len(tx)) + "   zipped " + str(
                #                  len(zp))).grid(row=9, column=3, columnspan=3, sticky="w", pady=2, padx=10)
                print("Scanning completed")

                button1.config(state=tkinter.NORMAL)
                button2.config(state=tkinter.NORMAL)
                button3.config(state=tkinter.NORMAL)
                button4.config(state=tkinter.NORMAL)
                #button5.config(state=tkinter.NORMAL)
                button6.config(state=tkinter.NORMAL)
                #label3.config(text="Scanning completed", anchor="nw")
                #label3.config(text=language_data[27], anchor="nw")

                #T3.configure(state="normal")
                T3.delete("1.0", "end")
                T3.insert("1.0", language_data[27])
                #T3.configure(state="disabled")

                mainwindow.after(0, lambda: label2.config(
                    text="Total # of files: " + str(count_file) + "   # of files scanned: " + str(
                        count_file) + "   Percentage: " + "{:.0f}%".format(
                        100) + "\nTime Elapsed: " + time_output))
                        #count_progress) + "   Percentage: " + "{:.0f}%".format(count_progress / count_file * 100) + "\nTime Elapsed: " + time_output))

                runState = 0

                if os.path.exists(out):
                    deleteTempfolder(out)

                if os.path.exists(out_legacy):
                    deleteTempfolder(out_legacy)

    '''print("docx %s" % len(d))
    print("pptx %s" % len(pp))
    print("pdf %s" % len(pdf))
    print("doc %s" % len(d2))
    print("xlsx %s" % len(xl))
    print("zipped %s" % len(zp))'''


def on_closing():
    global mainwindow
    mainwindow.quit()


def main():

    createUI()


if __name__ == "__main__":
    main()

